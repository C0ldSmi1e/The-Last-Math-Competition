#!/usr/bin/env python3
"""Recheck raw evidence, publish the scoped verdict, and freeze a compact file list."""
import collections,datetime,hashlib,json,os
from pathlib import Path
import shutil

D=Path('/Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work')
E=D/'1741/engineering'
FULL=E/'full-v1'
AUTHOR=D/'1741/author'
VERDICT=E/'engineering-verdict-v1.json'
MANIFEST=E/'engineering-evidence-manifest-v1.json'
assert not VERDICT.exists() and not MANIFEST.exists()

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as stream:
        for block in iter(lambda:stream.read(1048576),b''):h.update(block)
    return h.hexdigest()

def read(p):return json.loads(p.read_text())
def save(p,data):p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

frozen=read(D/'1741/frozen-v1.json')
for name,digest in frozen['files'].items():
    assert sha(AUTHOR/name)==digest
    assert sha(E/'author-verifier-v1'/name)==digest
for path,digest in read(E/'full-v1-orchestration-identities.json').items():
    assert sha(Path(path))==digest
summary=read(FULL/'summary.json')
assert summary['status']=='PASS_PENDING_RUNTIME_HELPER_CLASSIFICATION'
assert summary['frozen_manifest_sha256']==sha(D/'1741/frozen-v1.json')
assert not summary['audit_failures']
assert not read(FULL/'active-source-token-audit.json')
assert all(r['unchanged'] for r in read(FULL/'stock-index-stability.json'))
assert all(sha(Path(path))==digest for path,digest in read(FULL/'runtime-identities.json').items())

receipt_rows=[]
for folder in (E/'prepare-001/receipts',FULL/'receipts',E/'full-v1-command-receipts',E/'helper-provenance-v1'):
    for path in sorted(folder.glob('*.json')):
        data=read(path)
        if not isinstance(data,dict) or 'argv' not in data:continue
        assert sha(path.with_suffix('.stdout'))==data['stdout_sha256']
        assert sha(path.with_suffix('.stderr'))==data['stderr_sha256']
        expected=data.get('expected_exit',0)
        assert data['exit_code']!=0 if expected=='nonzero' else data['exit_code']==expected
        project=folder.parent/'project' if folder.name=='receipts' else folder
        for source,digest in data.get('active_source_hashes',{}).items():
            assert sha(project/source)==digest,(path,source)
        receipt_rows.append({'path':str(path.relative_to(E)),'sha256':sha(path),
                             'exit_code':data['exit_code'],'expected_exit':expected})
outer=read(E/'prepare-command.json')
assert outer['exit_code']==0
assert sha(E/'prepare-command.stdout')==outer['stdout_sha256']
assert sha(E/'prepare-command.stderr')==outer['stderr_sha256']
receipt_rows.append({'path':'prepare-command.json','sha256':sha(E/'prepare-command.json'),'exit_code':0,'expected_exit':0})

assert read(E/'full-v1-orchestration-results.json')['status']=='COMMANDS_PASS_PENDING_ENGINEERING_REVIEW'
graph_check=json.loads((E/'full-v1-command-receipts/graph-check.stdout').read_text())
assert graph_check['status']=='PASS'
audit=read(FULL/'declaration-audit.json')
roots={r['name']:r for r in audit['declarations']}
safe={name:r for name,r in roots.items() if not r['unsafe']}
permitted={'propext','Classical.choice','Quot.sound'}
assert all(r['trust_enforced'] and not r['unsafe_dependencies'] and set(r['axioms'])<=permitted for r in safe.values())
assert set(frozen['capstones'])<=set(safe)
classification=read(E/'helper-provenance-v1/classification.json')
assert classification['status']=='PASS_EXPLICIT_GENERATED_HELPER_CLASSIFICATION'
assert classification['original_audit_sha256']==sha(FULL/'declaration-audit.json')
assert classification['fixture_audit_sha256']==sha(E/'helper-provenance-v1/fixture-audit.json')
assert classification['driver_sha256']==sha(E/'run_helper_provenance_v1.py')
assert {r['name'] for r in classification['helpers']}=={name for name,r in roots.items() if r['unsafe']}
for row in classification['helpers']:
    assert not row['capstones_reaching_helper'] and not row['safe_owned_roots_reaching_helper']
    assert all(row['fresh_reproduction_comparisons'].values())
    assert sha(Path(row['source_path']))==row['source_sha256']
printed=(E/'helper-provenance-v1/inspect.stdout').read_text().split('unsafe def ')[1:]
assert len(printed)==4
for a,b in ((printed[0],printed[1]),(printed[2],printed[3])):
    assert a.split(' : ',1)[1].strip()==b.split(' : ',1)[1].strip()

imports=read(FULL/'import-identities.json')
assert len(imports)==summary['import_identity_count']
assert len({r['module'] for r in imports})==len(imports)
counts=collections.Counter()
for row in imports:
    path=Path(row['resolved_path'])
    assert sha(path)==row['olean_sha256'],row['module']
    counts[row['package']]+=1
    if 'source_sha256' in row:
        relative=Path(*row['module'].split('.')).with_suffix('.lean')
        if row['package']=='owned':source=FULL/'project'/relative
        else:
            stock=D/'runtime/stock1925'
            source=(stock if row['package']=='mathlib' else stock/'.lake/packages'/row['package'])/relative
        assert sha(source)==row['source_sha256'],row['module']
for name in ('lake-build-outputs.json','replay-build-outputs.json','audited-build-outputs.json'):
    for relative,digest in read(FULL/name).items():
        assert sha(FULL/'project/.lake/build/lib/lean'/relative)==digest
assert read(FULL/'lake-build-outputs.json')==read(FULL/'replay-build-outputs.json')

toolcopy=E/'reproduction-tools-v1'
toolcopy.mkdir()
(toolcopy/'templates').mkdir()
for name in ('verify.py','check_audit_graph.py','test_hardening.py','templates/ClosureAudit.lean.txt'):
    original=D/'verification-tools'/name
    dest=toolcopy/name
    shutil.copy2(original,dest)
    assert sha(original)==sha(dest)

save(VERDICT,{
    'status':'PASS_ENGINEERING_FOR_FROZEN_V1',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'frozen_manifest_sha256':sha(D/'1741/frozen-v1.json'),
    'finalizer_sha256':sha(Path(__file__)),
    'checks':{
        'default_lake_build_warnings_fatal':True,'lakefile_executed_under_strict_lean':True,
        'every_owned_lean_module_replayed_warnings_fatal':True,
        'all_owned_library_outputs_attributed':True,'author_verifier_executed_in_fresh_private_copy':True,
        'full_type_body_recursor_inductive_dependency_audit':True,'independent_exported_graph_recomputation':True,
        'fresh_generic_positive_and_negative_controls':True,'adversarial_driver_controls':True,
        'all_frozen_original_and_private_source_bytes_unchanged':True,'no_network_or_dependency_restoration_needed':True},
    'owned_modules':summary['modules'],'exported_local_declarations':len(roots),'safe_exported_local_declarations':len(safe),
    'closure_declarations':summary['closure_declaration_count'],'module_counts':audit['module_counts'],
    'verification_examples_note':'Verification.lean exports no persistent declarations because its checks are examples; the complete file compiled in both default Lake build and strict direct replay.',
    'capstones':[{k:safe[name][k] for k in ('name','kind','type','raw_type','axioms','unsafe_dependencies')} for name in frozen['capstones']],
    'imported_modules':len(imports),'imported_modules_by_package':dict(counts),
    'runtime_helpers':classification,'receipt_review':receipt_rows,
    'retained_unexpected_failures':['retained-failure-001/observed-result.json'],
    'retained_failure_explanation':'Initial extra preflight incorrectly required every package cache to be nonempty. Cli was empty. The failed preflight was preserved; full default build, replay, and all actual imports subsequently passed with existing caches.',
    'scope_limits':[
        'Engineering verdict only; semantic correspondence to the informal candidate and independent mathematical review are separate.',
        'Pinned generic dependency source bytes match Git objects; dependency oleans are bound to supplied cached bytes and were not independently authenticated or rebuilt.',
        'The supplied Lean runtime was hashed and checked stable, not bootstrapped.',
        'The closure inspector exports dependency evidence; kernel checking is supplied by the fresh Lean compilations.',
        'The independent Python graph checker recomputes the exported graph, not a second Lean environment extraction.',
        'The two reproduced unsafe compiler helpers retain all runtime findings; none is reachable from any safe owned declaration or capstone.',
        'Offline PATH wrappers are safeguards, not OS network isolation.'
    ]})

files=[]
excluded_dirs={'.lake','.verification-build','__pycache__','.git'}
excluded_suffixes={'.olean','.ilean','.ir','.o','.c','.a','.so','.dylib','.pyc'}
for directory,names,filenames in os.walk(E):
    names[:]=sorted(n for n in names if n not in excluded_dirs)
    for name in sorted(filenames):
        path=Path(directory)/name
        if path==MANIFEST or path.suffix in excluded_suffixes:continue
        if path.is_symlink():raise AssertionError('Unexpected linked evidence: '+str(path))
        files.append({'path':str(path.relative_to(E)),'sha256':sha(path),'bytes':path.stat().st_size})
save(MANIFEST,{
    'frozen':True,'status':'FROZEN_ENGINEERING_EVIDENCE_V1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'root':str(E),'files':files,'file_count':len(files),'bytes':sum(r['bytes'] for r in files),
    'excluded':'Cloned .lake trees, runtime/build caches, compiled products, and this self-referential manifest. Raw sources, graphs, fixture audits, receipts, logs, tool copies, and operational drivers remain included.',
    'operational_driver_files':['run_preparation.py','run_preparation_v2.py','run_full_v1.py','run_helper_provenance_v1.py','finalize_engineering_v1.py'],
    'reproduction':{
        'full_verifier':'python3 reproduction-tools-v1/verify.py verify SUBMISSION FROZEN_JSON PINNED_STOCK LEAN_BIN FRESH_OUTPUT EXPECTED_PINS',
        'closure_checker':'python3 reproduction-tools-v1/check_audit_graph.py FRESH_OUTPUT/declaration-audit.json',
        'hardening':'python3 reproduction-tools-v1/test_hardening.py FRESH_HARDENING_OUTPUT',
        'author_auxiliary':'Copy frozen sources to a fresh directory; run python3 verify.py --runtime-root RUNTIME_ROOT there.',
        'required_external_runtime':'Exact pinned stock and Lean 4.19.0 runtime identified in full-v1 package, import, and runtime identity records. Excluded from this compact evidence list.'}})
print(json.dumps({'verdict':str(VERDICT),'verdict_sha256':sha(VERDICT),'manifest':str(MANIFEST),'manifest_sha256':sha(MANIFEST),'evidence_files':len(files),'evidence_bytes':sum(r['bytes'] for r in files),'receipt_count':len(receipt_rows),'status':'PASS_ENGINEERING_FOR_FROZEN_V1'},indent=2),flush=True)
