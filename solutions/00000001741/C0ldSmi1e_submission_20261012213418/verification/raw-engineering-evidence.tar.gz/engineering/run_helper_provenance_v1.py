#!/usr/bin/env python3
"""Classify two observed compiler helpers with a fresh isolated reproduction."""
import hashlib,json,os
from pathlib import Path
import subprocess,time
D=Path('/Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work')
E=D/'1741/engineering'
FULL=E/'full-v1'
OUT=E/'helper-provenance-v1'
OUT.mkdir()
LIB=OUT/'lib'
LIB.mkdir()
LEAN=D/'runtime/lean-4.19.0-darwin_aarch64/bin/lean'
AUTHOR=D/'1741/author/HallReverse.lean'
source=AUTHOR.read_text()
definition='def gap (x y : ℕ) : ℝ := |(x : ℝ) ^ 3 - (y : ℝ) ^ 2|'
assert source.count(definition)==1
imports='\n'.join(line for line in source.splitlines() if line.startswith('import '))
(OUT/'GapProvenance.lean').write_text(imports+'\n\nnamespace EngineeringGapFixture\n'+definition+'\nend EngineeringGapFixture\n')
(OUT/'Inspect.lean').write_text('import GapProvenance\nimport HallReverse\nimport Verification.ClosureAudit\n#inspect_modules [GapProvenance] "fixture-audit.json"\n#print HallReverse.gap._cstage1\n#print EngineeringGapFixture.gap._cstage1\n#print HallReverse.gap._cstage2\n#print EngineeringGapFixture.gap._cstage2\n')
manifest=json.loads((D/'1741/clean-author-input/lake-manifest.json').read_text())
paths=[LIB,FULL/'project/.lake/build/lib/lean']+[FULL/'project/.lake/packages'/p['name']/'.lake/build/lib/lean' for p in manifest['packages']]
env=dict(os.environ)
for key in ('LEAN_PATH','LEAN_SRC_PATH','LEAN_SYSROOT','LAKE_HOME'):env.pop(key,None)
env['LEAN_PATH']=':'.join(map(str,paths))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
for name,args in [('compile',['-o',LIB/'GapProvenance.olean','GapProvenance.lean']),('inspect',['Inspect.lean'])]:
    argv=[LEAN,'-DwarningAsError=true',*args]
    t=time.time()
    result=subprocess.run(list(map(str,argv)),cwd=OUT,env=env,capture_output=True)
    prefix=OUT/name
    prefix.with_suffix('.stdout').write_bytes(result.stdout)
    prefix.with_suffix('.stderr').write_bytes(result.stderr)
    save(prefix.with_suffix('.json'),{'argv':list(map(str,argv)),'cwd':str(OUT),'exit_code':result.returncode,'seconds':time.time()-t,'environment':{'LEAN_PATH':env['LEAN_PATH']},'stdout_sha256':sha(prefix.with_suffix('.stdout')),'stderr_sha256':sha(prefix.with_suffix('.stderr')),'active_source_hashes':{p.name:sha(p) for p in OUT.glob('*.lean')}})
    print(name+': exit '+str(result.returncode),flush=True)
    assert result.returncode==0
audit=json.loads((FULL/'declaration-audit.json').read_text())
fixture=json.loads((OUT/'fixture-audit.json').read_text())
roots={d['name']:d for d in audit['declarations']}
reproduced={d['name']:d for d in fixture['declarations']}
frozen=json.loads((D/'1741/frozen-v1.json').read_text())
helpers=json.loads((FULL/'runtime-helper-inventory.json').read_text())
expected={'HallReverse.gap._cstage1','HallReverse.gap._cstage2'}
assert {d['name'] for d in helpers}==expected
fields=['kind','unsafe','type','raw_type','type_dependencies','body_dependencies','recursor_dependencies','inductive_dependencies']
rows=[]
for helper in helpers:
    name=helper['name']
    other_name=name.replace('HallReverse.gap','EngineeringGapFixture.gap')
    other=reproduced[other_name]
    comparisons={field:helper[field]==other[field] for field in fields}
    assert all(comparisons.values()),(name,comparisons)
    reached_by_safe=[d['name'] for d in audit['declarations'] if not d['unsafe'] and name in d['closure']]
    reached_by_capstones=[name0 for name0 in frozen['capstones'] if name in roots[name0]['closure']]
    assert not reached_by_safe and not reached_by_capstones
    rows.append({'name':name,'classification':'Generated compiler-stage implementation of the source gap definition; excluded from kernel evidence','source_path':str(AUTHOR),'source_sha256':sha(AUTHOR),'source_line':source[:source.index(definition)].count('\n')+1,'source_definition':definition,'fresh_reproduction':other_name,'fresh_reproduction_comparisons':comparisons,'safe_owned_roots_reaching_helper':reached_by_safe,'capstones_reaching_helper':reached_by_capstones,'remaining_runtime_findings':[f for f in audit['compiler_runtime_findings'] if f.startswith(name+':')]})
assert not roots['HallReverse.gap']['unsafe']
assert not roots['HallReverse.gap']['unsafe_dependencies']
save(OUT/'classification.json',{'status':'PASS_EXPLICIT_GENERATED_HELPER_CLASSIFICATION','driver_sha256':sha(Path(__file__)),'fixture_source_sha256':sha(OUT/'GapProvenance.lean'),'fixture_audit_sha256':sha(OUT/'fixture-audit.json'),'original_audit_sha256':sha(FULL/'declaration-audit.json'),'helpers':rows,'source_gap_safe':True,'source_gap_unsafe_dependencies':[],'scope':'The two compiler helper roots are reproduced from the exact safe source definition in a fresh module. Runtime-only findings remain recorded; none is reachable from any safe owned root or any capstone. This is not a waiver for other unsafe roots.'})
print('PASS_EXPLICIT_GENERATED_HELPER_CLASSIFICATION',flush=True)
