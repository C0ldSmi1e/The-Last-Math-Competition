#!/usr/bin/env python3
"""Final candidate 7160 public metadata refresh. Network requires explicit CLI trigger."""
import ast,base64,csv,datetime,hashlib,io,json,pathlib,re,subprocess,sys,time,urllib.parse
P=pathlib.Path(__file__).parent;W=P.parents[1];N=W/'neutral-after3992-hold';B=P.parent/'eligibility';R='The-Last-Math-Competition/The-Last-Math-Competition';CAP=30;SECONDS=120
module=ast.parse((N/'rebuild.py').read_text());names={'utc','sha','canonical','require','save','load','Evidence'}
exec(compile(ast.Module(body=[n for n in module.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names],type_ignores=[]),str(N/'rebuild.py'),'exec'))
C='00000007160';SOURCE='9c06819d1b860698509318573cd687bcc668528517ad37872e78758a4c6254fd';SINCE='2026-10-12T19:22:20Z'
patterns=load(B/'preparation.json')['patterns'];QUERIES=['7160','"00000007160"','"solutions/00000007160"','"Hoffman"','"Wielandt"','"Frobenius"','"谱变分"','"霍夫曼"','"normal matrices"','"spectral variation"']
def hits(text):return [k for k,p in patterns.items() if re.search(p,text or '',re.I)]
def operative(blob,heading):
 text=blob.decode();m=re.search(r'^## '+re.escape(heading)+r'\s*\n[\s\S]*?(?=^## |\Z)',text,re.M);require('operative rules section found',m is not None);return (m.group().rstrip('\n')+'\n').encode()
def decode_blob(z):
 b=base64.b64decode(z['content']);require('exact contents blob',hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==z['sha']);return b
if sys.argv[1:]!=['--execute-final-refresh']:
 print('PREPARED_ONLY: no network. Root trigger required: python3 refresh.py --execute-final-refresh');sys.exit(0)
# Every pinned dependency is rehashed before network. Prior topic classifications are root assertions.
for name,h in load(P/'dependency-pins.json').items():require('dependency hash '+name,sha(pathlib.Path(name).read_bytes())==h)
E=Evidence(P/'capture');snap=load(N/'capture/current-neutral-snapshot.json');oldissues={x['number']:x for x in snap['issues']};oldprs={x['number']:x for x in snap['prs']};oldcomments={x['id']:x for x in snap['comments']};oldinline={x['id']:x for x in snap['inline']};oldreviews={x['id']:x for r in snap['reviews'] for x in r['reviews']['nodes']};contexts={};flags=[];searchsummaries=[];prior_classified=load(B/'capture/baseline-metadata-matches.json');prior_pr_ids={x['number_or_id'] for x in prior_classified if x['kind'] in ['pull_request','issue']}
result={'status':'HOLD_INCOMPLETE','candidate':C,'request_cap':CAP,'seconds_cap':SECONDS,'scope':'Current public upstream exact source/operative rules/metadata/path and complete same-path main history; targeted searches; issue/comment/inline delta since cutoff; changed PR metadata/reviews, with filenames for new or changed heads. No solution proof contents, every-fork or full-DAG claim. Existing 41 broad contexts classified unrelated by root; new or changed contexts flagged for root.'}
def inspect(kind,key,fields,oldfields=None,search_hit=False):
 matched={k:hits(v) for k,v in fields.items() if isinstance(v,str) and hits(v)}
 if matched or search_hit:
  changed=oldfields is None or fields!=oldfields or (search_hit and key not in prior_pr_ids);row={'kind':kind,'id':key,'matches':matched,'metadata_context':fields,'new_or_changed':changed};contexts[kind+':'+str(key)]=row
  if changed:flags.append({'kind':kind,'id':key,'reason':'New or changed matching metadata context'})
def issuefields(x):return {'title':x['title'],'body':x.get('body') or '','url':x['html_url']}
try:
 main,_=E.get('main-start.json','repos/'+R+'/git/ref/heads/main');mainsha=main['object']['sha'];same=mainsha==snap['identity']['main_sha']
 if same:tree=load(N/'capture/main-root-tree.json');soltree=load(N/'capture/current-solution-directory-tree.json')
 else:
  commit,_=E.get('main-git-commit.json','repos/'+R+'/git/commits/'+mainsha);tree,_=E.get('main-root-tree.json','repos/'+R+'/git/trees/'+commit['tree']['sha']);require('root tree complete',not tree['truncated']);sentry=next(x for x in tree['tree'] if x['path']=='solutions');soltree,_=E.get('solution-directory-tree.json','repos/'+R+'/git/trees/'+sentry['sha'])
 byname={x['path']:x for x in tree['tree']};require('solution tree complete and bound',not soltree['truncated'] and soltree['sha']==byname['solutions']['sha']);paths=[x for x in soltree['tree'] if x['path']==C];save(E.path/'current-path.json',{'main':mainsha,'root_tree':tree['sha'],'solution_tree':soltree['sha'],'reused_exact_main_trees':same,'candidate_path':'solutions/'+C,'matching_entries':paths});require('candidate path remains absent',not paths)
 source,_=E.get('current-original.json','repos/'+R+'/contents/conjectures/'+C+'.md?ref='+mainsha);require('original bytes unchanged',sha(decode_blob(source))==SOURCE)
 rules=[]
 for lang,path,heading,local in [('en','README.md','Rules','RULES.en.md'),('zh','README.zh-CN.md','比赛规则','RULES.zh-CN.md')]:
  z,_=E.get('current-rules-'+lang+'.json','repos/'+R+'/contents/'+path+'?ref='+mainsha);b=decode_blob(z);require('root rules blob bound',z['sha']==byname[path]['sha']);section=operative(b,heading);clean=(W/'3992/current-input'/local).read_bytes();require('operative rules bytes unchanged',section==clean);rules.append({'path':path,'whole_blob_sha256':sha(b),'operative_sha256':sha(section),'git_blob_sha':z['sha']})
 md,_=E.get('current-metadata.json','repos/'+R+'/contents/metadata.csv?ref='+mainsha);blob=decode_blob(md);require('metadata root binding',md['sha']==byname['metadata.csv']['sha']);rows=[x for x in csv.DictReader(io.StringIO(blob.decode())) if x['id']==C];require('single candidate metadata row',len(rows)==1);save(E.path/'current-identities.json',{'main':mainsha,'original_sha256':SOURCE,'original_git_blob':source['sha'],'rules':rules,'metadata_sha256':sha(blob),'metadata_git_blob':md['sha'],'candidate_metadata':rows[0]});require('candidate remains unsolved',all(str(rows[0].get(k,'')).lower() not in ['1','true','yes'] for k in ['proven','disproven']))
 history=E.pages('same-path-history.json','repos/'+R+'/commits?sha='+mainsha+'&path=solutions/'+C+'&per_page=100');require('no main candidate path history',not history)
 for i,term in enumerate(QUERIES):
  q='repo:'+R+' '+term;items=[];total=None
  for page in range(1,6):
   d,h=E.get('search-%02d-page-%02d.json'%(i,page),'search/issues?q='+urllib.parse.quote(q,safe='')+'&per_page=100&page='+str(page));require('search complete flag',d.get('incomplete_results') is False);require('search finite total',d['total_count']<=500);require('search total stable',total is None or total==d['total_count']);total=d['total_count'];items+=d['items']
   if len(items)>=total:break
  require('search all results retained',len(items)==total==len({x['id'] for x in items}));summary={'query':q,'total_count':total,'numbers':[x['number'] for x in items]};searchsummaries.append(summary);save(E.path/('search-%02d-complete.json'%i),summary)
  for x in items:
   old=oldissues.get(x['number']);inspect('issue_or_pr',x['number'],issuefields(x),issuefields(old) if old else None,True)
 delta=E.pages('delta-issues.json','repos/'+R+'/issues?state=all&since='+SINCE+'&sort=updated&direction=asc&per_page=100');comments=E.pages('delta-comments.json','repos/'+R+'/issues/comments?since='+SINCE+'&sort=updated&direction=asc&per_page=100');inline=E.pages('delta-inline.json','repos/'+R+'/pulls/comments?since='+SINCE+'&sort=updated&direction=asc&per_page=100')
 for x in delta:
  old=oldissues.get(x['number']);inspect('issue_or_pr',x['number'],issuefields(x),issuefields(old) if old else None)
 for kind,items,prior in [('issue_comment',comments,oldcomments),('inline_comment',inline,oldinline)]:
  for x in items:
   old=prior.get(x['id']);inspect(kind,x['id'],{'body':x.get('body') or '','url':x.get('html_url','')},{'body':old.get('body') or '','url':old.get('html_url','')} if old else None)
 nums=sorted({x['number'] for x in delta if 'pull_request' in x});require('changed PR finite scope',len(nums)<=20);prdelta=[];projected=[]
 if nums:
  q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){'+''.join('p'+str(n)+':pullRequest(number:'+str(n)+'){number title body state updatedAt mergedAt closedAt headRefOid baseRefOid changedFiles reviews(first:100){totalCount nodes{id databaseId body state submittedAt author{login}} pageInfo{hasNextPage endCursor}}}' for n in nums)+'}}';raw,_=E.get('changed-pr-metadata.json','graphql',q)
  for z in raw['data']['repository'].values():
   n=z['number'];c=z['reviews'];seen=set()
   for tail in range(5):
    if not c['pageInfo']['hasNextPage']:break
    cursor=c['pageInfo']['endCursor'];require('review cursor advances',cursor not in seen);seen.add(cursor);q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){pullRequest(number:'+str(n)+'){headRefOid reviews(first:100,after:'+json.dumps(cursor)+'){totalCount nodes{id databaseId body state submittedAt author{login}} pageInfo{hasNextPage endCursor}}}}}';extra,_=E.get('changed-pr-'+str(n)+'-review-tail-'+str(tail)+'.json','graphql',q);part=extra['data']['repository']['pullRequest'];nc=part['reviews'];require('review head and total stable',part['headRefOid']==z['headRefOid'] and nc['totalCount']==c['totalCount']);c['nodes']+=nc['nodes'];c['pageInfo']=nc['pageInfo']
   require('review pagination complete',not c['pageInfo']['hasNextPage'] and len(c['nodes'])==len({x['id'] for x in c['nodes']})==c['totalCount'])
   for rv in c['nodes']:
    old=oldreviews.get(rv['id']);inspect('review',rv['id'],{'body':rv.get('body') or '','state':rv['state']},{'body':old.get('body') or '','state':old['state']} if old else None)
   old=oldprs.get(n);z['head_changed_or_new']=old is None or old['headRefOid']!=z['headRefOid'];prdelta.append(z)
  needed=[x for x in prdelta if x['head_changed_or_new']]
  if needed:
   q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){'+''.join('p'+str(x['number'])+':pullRequest(number:'+str(x['number'])+'){number headRefOid baseRefOid changedFiles files(first:100){totalCount nodes{path} pageInfo{hasNextPage endCursor}}}' for x in needed)+'}}';raw,_=E.get('changed-head-filenames.json','graphql',q)
   for old in needed:
    n=old['number'];z=raw['data']['repository']['p'+str(n)];require('filename head stable',z['headRefOid']==old['headRefOid']);c=z['files'];seen=set()
    for tail in range(5):
     if not c['pageInfo']['hasNextPage']:break
     cursor=c['pageInfo']['endCursor'];require('file cursor advances',cursor not in seen);seen.add(cursor);q='query{repository(owner:"The-Last-Math-Competition",name:"The-Last-Math-Competition"){pullRequest(number:'+str(n)+'){headRefOid files(first:100,after:'+json.dumps(cursor)+'){totalCount nodes{path} pageInfo{hasNextPage endCursor}}}}}';extra,_=E.get('changed-pr-'+str(n)+'-files-tail-'+str(tail)+'.json','graphql',q);part=extra['data']['repository']['pullRequest'];nc=part['files'];require('file head total stable',part['headRefOid']==z['headRefOid'] and nc['totalCount']==c['totalCount']);c['nodes']+=nc['nodes'];c['pageInfo']=nc['pageInfo']
    paths=[x['path'] for x in c['nodes']];require('complete filename projection',not c['pageInfo']['hasNextPage'] and len(paths)==len(set(paths))==c['totalCount']==z['changedFiles']);projected.append({'number':n,'head_sha':z['headRefOid'],'paths':paths})
    if any(re.search(r'(?<!\d)'+C+r'(?!\d)',x) for x in paths):flags.append({'kind':'candidate_filename','id':n,'reason':'Candidate ID in new or changed PR head filename metadata'})
 save(E.path/'complete-changed-pr-metadata.json',prdelta);save(E.path/'complete-changed-head-filenames.json',projected);end,_=E.get('main-final.json','repos/'+R+'/git/ref/heads/main');require('main stable through capture',end['object']['sha']==mainsha)
 result.update(status='BOUNDED_REFRESH_COMPLETE_ROOT_REVIEW_REQUIRED',main_sha=mainsha,main_changed_from_baseline=not same,original_sha256=SOURCE,operative_rules_unchanged=True,solution_path_absent=True,same_path_history_count=len(history),delta_since=SINCE,delta_counts={'issues':len(delta),'comments':len(comments),'inline':len(inline)},changed_pr_numbers=nums,projected_changed_head_numbers=[x['number'] for x in projected],search_summaries=searchsummaries,flag_count=len(flags),context_count=len(contexts))
except Exception as ex:result['error']=repr(ex)
finally:
 save(E.path/'matching-contexts.json',list(contexts.values()));save(E.path/'root-review-flags.json',flags);save(E.path/'errors.json',E.errors);save(E.path/'retry-resolutions.json',E.resolutions);save(E.path/'pagination-index.json',E.pages_log);result.update(actual_requests=E.n,elapsed_seconds=time.monotonic()-E.start,observed_from=min((x['started_at'] for x in E.records),default=None),observed_through=max((x['completed_at'] for x in E.records),default=None));save(P/'result.json',result);save(P/'SHA256SUMS.json',{str(x.relative_to(P)):sha(x.read_bytes()) for x in sorted(P.rglob('*')) if x.is_file() and x!=P/'SHA256SUMS.json'});print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
