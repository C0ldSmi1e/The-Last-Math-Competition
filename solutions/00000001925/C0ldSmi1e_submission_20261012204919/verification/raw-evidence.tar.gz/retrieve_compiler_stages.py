#!/usr/bin/env python3
"""Fetch the compiler stage-cache implementation file at the resolved official release commit."""
import datetime,hashlib,json,time,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;prior=P/'compiler-provenance-v1';out=P/'compiler-stage-provenance-v1'
assert not out.exists();out.mkdir();(out/'driver.py.txt').write_bytes(Path(__file__).read_bytes())
a=json.loads((prior/'selected-commit.json').read_text());commit=a['commit'];assert commit=='6caaee842e9495688c1567e78c0e68dbb96942aa'
tree={r['path']:r for r in json.loads((prior/'tree.json').read_text())['tree']}
paths=['src/library/compiler/util.cpp'];records=[]
for i,path in enumerate(paths,1):
 url='https://raw.githubusercontent.com/leanprover/lean4/'+commit+'/'+path
 req=urllib.request.Request(url,headers={'User-Agent':'pinned-lean-compiler-provenance'})
 started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with urllib.request.urlopen(req,timeout=60) as r:body=r.read();status=r.status;headers=dict(r.headers)
 target=out/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(body)
 blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest();assert blob==tree[path]['sha']
 rec={'url':url,'path':path,'http_status':status,'response_headers':headers,'started_utc':started,'elapsed_seconds':time.monotonic()-t,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'git_blob':blob,'matches_official_tag_tree':True}
 (out/(f'http-{i:03d}.json')).write_text(json.dumps(rec,indent=2,sort_keys=True)+'\n');records.append(rec)
result={'status':'PASS','tag':'v4.19.0','commit':commit,'files':records,'limits':'Official release source identity corroborates compiler naming and generated unsafe declarations; the runtime is not rebuilt or bootstrapped here.'}
(out/'summary.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(result,indent=2))
