#!/usr/bin/env python3
"""Read-only exact helper printing using independently built candidate modules."""
import datetime,hashlib,json,os,re,subprocess,time
from pathlib import Path
P=Path(__file__).resolve().parent;D=P.parent;review=P/'engineering-review-v1';out=P/'runtime-helper-review-v1'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
assert not out.exists();out.mkdir();(out/'driver.py.txt').write_bytes(Path(__file__).read_bytes())
helpers=json.loads((review/'runtime-helper-inventory.json').read_text());names=[r['name'] for r in helpers]
assert len(names)==len(set(names))==22
assert all(r['unsafe'] and r['module'] in {'Conjecture1925.Dynamics','Conjecture1925.Measure'} for r in helpers)
assert all(re.fullmatch(r'Conjecture1925\.[A-Za-z_0-9Ω.]+',n) for n in names)
source=out/'InspectRuntimeHelpers.lean'
source.write_text('import Conjecture1925\nset_option pp.all true\nset_option pp.width 120\n'+''.join('#print '+n+'\n' for n in names))
previous=json.loads((review/'receipts/0046.json').read_text())
env=os.environ.copy()
for k in ['LEAN_SRC_PATH','LEAN_SYSROOT','LAKE_HOME']:env.pop(k,None)
env.update(previous['environment'])
argv=[str(D/'runtime/lean-4.19.0-darwin_aarch64/bin/lean'),'-DwarningAsError=true','--root='+str(out),str(source)]
t=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
with (out/'stdout.txt').open('wb') as so,(out/'stderr.txt').open('wb') as se:r=subprocess.run(argv,cwd=out,env=env,stdout=so,stderr=se)
save(out/'receipt.json',{'argv':argv,'cwd':str(out),'started_utc':started,'elapsed_seconds':time.monotonic()-t,'exit_code':r.returncode,'stdout_sha256':h(out/'stdout.txt'),'stderr_sha256':h(out/'stderr.txt'),'environment':previous['environment'],'input_helper_inventory_sha256':h(review/'runtime-helper-inventory.json'),'inspection_source_sha256':h(source),'inspected_exact_names':names,'scope':'Inspection of compiled runtime declarations only; no proof rerun, candidate edit, emitted olean, or stock mutation'})
print(json.dumps({'exit_code':r.returncode,'receipt':str(out/'receipt.json'),'helper_count':len(names)},indent=2))
assert r.returncode==0
