#!/usr/bin/env python3
"""Candidate-independent operational preparation; never reads author proof files."""
from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, time

OUT = Path('/private/tmp/tlmc4125-engineering-prep')
SOURCE_TOOLS = Path('/private/tmp/tlmc3348-engineering-tools')
TOOLS = Path('/private/tmp/tlmc4125-engineering-tools')
PINS = Path('/private/tmp/tlmc4125-clean-author-input')
STOCK = Path('/private/tmp/tlmc4607-restored-stock/mathlib')
PRIVATE = OUT/'private-stock/mathlib'
BIN = Path('/private/tmp/tlmc310-runtime/lean-4.19.0-darwin_aarch64/bin')
ENV = os.environ.copy()
for key in list(ENV):
    if key.startswith('GIT_') or key in ('LEAN_PATH','LEAN_SRC_PATH','LAKE_HOME','LEAN_SYSROOT'):
        ENV.pop(key)
ENV.update(GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1')
RECEIPTS = OUT/'prep-receipts'
RECEIPTS.mkdir(exist_ok=False)
counter = 0

def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''): h.update(chunk)
    return h.hexdigest()

def save(p,data):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

def run(argv,cwd=OUT,expected=0):
    global counter
    counter += 1
    argv=list(map(str,argv));start=time.time()
    r=subprocess.run(argv,cwd=cwd,env=ENV,capture_output=True)
    prefix=RECEIPTS/f'{counter:04d}'
    prefix.with_suffix('.stdout').write_bytes(r.stdout)
    prefix.with_suffix('.stderr').write_bytes(r.stderr)
    save(prefix.with_suffix('.json'),{'argv':argv,'cwd':str(cwd),'returncode':r.returncode,
        'expected_exit':expected,'seconds':time.time()-start,
        'stdout_sha256':sha(prefix.with_suffix('.stdout')),
        'stderr_sha256':sha(prefix.with_suffix('.stderr')),
        'environment':{k:ENV[k] for k in ('GIT_OPTIONAL_LOCKS','GIT_NO_REPLACE_OBJECTS','PYTHONDONTWRITEBYTECODE')}})
    print(f'{counter:04}: exit {r.returncode}: {argv[0]} {argv[-1]}',flush=True)
    assert r.returncode==expected,(argv,r.returncode,r.stderr.decode(errors='replace'))
    return r.stdout

run(['/usr/bin/du','-sh',STOCK])
run(['/usr/bin/find',STOCK/'.lake/packages','-maxdepth','1','-type','l','-print'])
TOOLS.mkdir(exist_ok=False)
(TOOLS/'templates').mkdir()
tool_names=['verify.py','test_hardening.py','check_audit_graph.py','templates/ClosureAudit.lean.txt']
identities={}
for name in tool_names:
    run(['/bin/cp','-p',SOURCE_TOOLS/name,TOOLS/name])
    assert (SOURCE_TOOLS/name).read_bytes()==(TOOLS/name).read_bytes()
    identities[name]={'source':str(SOURCE_TOOLS/name),'copy':str(TOOLS/name),'sha256':sha(TOOLS/name),'byte_identical':True}
save(OUT/'tool-identities.json',identities)

pin_ids={}
for name in ['lean-toolchain','lake-manifest.json']:
    dest=OUT/'expected-pins'/name;dest.parent.mkdir(exist_ok=True)
    run(['/bin/cp','-p',PINS/name,dest])
    pin_ids[name]={'path':str(PINS/name),'sha256':sha(dest),'bytes':dest.stat().st_size}
assert (OUT/'expected-pins/lean-toolchain').read_text()=='leanprover/lean4:v4.19.0\n'
manifest=json.loads((OUT/'expected-pins/lake-manifest.json').read_text())
mathlib=next(x for x in manifest['packages'] if x['name']=='mathlib')
assert mathlib['rev']=='c44e0c8ee63ca166450922a373c7409c5d26b00b' and mathlib['inputRev']=='v4.19.0'
save(OUT/'pin-identities.json',pin_ids)

versions={}
versions['lean']=run([BIN/'lean','--version']).decode().strip()
versions['lake']=run([BIN/'lake','--version']).decode().strip()
assert 'version 4.19.0' in versions['lean'] and 'Lean version 4.19.0' in versions['lake']
run(['/usr/bin/otool','-L',BIN/'lean',BIN/'lake'])
save(OUT/'runtime-versions.json',versions)

# Native macOS copy control establishes independent file identity and mutation.
control=OUT/'copy-control';control.mkdir()
(control/'source').write_text('independent-copy-control\n')
run(['/bin/cp','-c',control/'source',control/'clone'])
before={n:{'sha256':sha(control/n),'device':(control/n).stat().st_dev,
    'inode':(control/n).stat().st_ino,'link_count':(control/n).stat().st_nlink} for n in ['source','clone']}
assert before['source']['sha256']==before['clone']['sha256']
assert (before['source']['device'],before['source']['inode'])!=(before['clone']['device'],before['clone']['inode'])
(control/'clone').write_text('changed-private-copy-control\n')
assert sha(control/'source')==before['source']['sha256'] and sha(control/'clone')!=before['clone']['sha256']
save(OUT/'copy-control.json',{'status':'PASS','before':before,'after':{n:sha(control/n) for n in ['source','clone']},
    'limit':'cp -c succeeded with separate inodes and independent mutation; physical block sharing was not independently measured.'})

PRIVATE.parent.mkdir()
index_before={}
for spec in manifest['packages']:
    source=STOCK if spec['name']=='mathlib' else STOCK/'.lake/packages'/spec['name']
    if (source/'.git/index').is_file(): index_before[spec['name']]=sha(source/'.git/index')
run(['/bin/cp','-cR',STOCK,PRIVATE])
packages=[]
for spec in manifest['packages']:
    name=spec['name']
    source=STOCK if name=='mathlib' else STOCK/'.lake/packages'/name
    dest=PRIVATE if name=='mathlib' else PRIVATE/'.lake/packages'/name
    head=run(['/usr/bin/git','rev-parse','HEAD'],cwd=source).decode().strip()
    assert head==spec['rev'],(name,head,spec['rev'])
    assert run(['/usr/bin/git','status','--porcelain','--untracked-files=no'],cwd=source)==b''
    tree=run(['/usr/bin/git','ls-tree','-r','-z','HEAD'],cwd=source)
    rows=[]
    for entry in tree.split(b'\0'):
        if not entry:continue
        meta,rawname=entry.split(b'\t',1)
        mode,kind,blob=meta.split();relative=rawname.decode()
        assert kind==b'blob'
        a,b=source/relative,dest/relative
        ab=os.readlink(a).encode() if a.is_symlink() else a.read_bytes()
        bb=os.readlink(b).encode() if b.is_symlink() else b.read_bytes()
        assert hashlib.sha1(b'blob '+str(len(ab)).encode()+b'\0'+ab).hexdigest()==blob.decode(),(name,relative)
        assert ab==bb,(name,relative)
        rows.append({'file':relative,'git_blob':blob.decode(),'sha256':hashlib.sha256(ab).hexdigest()})
    save(OUT/'stock-inventory'/f'{name}-tracked.json',rows)
    caches={}
    cache_root=source/'.lake/build/lib/lean'
    copy_cache=dest/'.lake/build/lib/lean'
    for path in sorted(cache_root.rglob('*.olean')):
        relative=path.relative_to(cache_root)
        digest=sha(path)
        assert sha(copy_cache/relative)==digest,(name,str(relative))
        assert (path.stat().st_dev,path.stat().st_ino)!=((copy_cache/relative).stat().st_dev,(copy_cache/relative).stat().st_ino)
        caches[str(relative)]=digest
    save(OUT/'stock-inventory'/f'{name}-cache.json',caches)
    packages.append({'name':name,'revision':head,'tracked_files':len(rows),'cache_olean_files':len(caches)})
save(OUT/'package-identities.json',packages)
run([sys.executable,TOOLS/'test_hardening.py',OUT/'hardening-controls'])
run([sys.executable,TOOLS/'verify.py','prepare',PRIVATE,BIN,OUT/'operational-controls'])
for name,digest in index_before.items():
    source=STOCK if name=='mathlib' else STOCK/'.lake/packages'/name
    assert sha(source/'.git/index')==digest
save(OUT/'stock-index-stability.json',{'status':'PASS','before':index_before,
    'note':'GIT_OPTIONAL_LOCKS=0 and no shared-stock writes were requested.'})
assert all(sha(TOOLS/name)==row['sha256'] for name,row in identities.items())
assert all(sha(PINS/name)==row['sha256'] for name,row in pin_ids.items())
save(OUT/'summary.json',{'status':'PREPARATION_PASS','candidate_proof_accessed':False,
    'private_stock':str(PRIVATE),'tools':str(TOOLS),'runtime_bin':str(BIN),
    'pins':pin_ids,'tool_identities':identities,'package_identities':packages,
    'limits':['No proof is validated by these operational controls.',
      'Stock source checked against pinned Git objects; supplied cached oleans only byte-matched, not rebuilt.',
      'Supplied runtime identified, not bootstrapped or authenticated against a separately fetched distribution.',
      'Native macOS cp -cR succeeded; independent inodes and copy mutation tested; physical block sharing not independently measured.',
      'No OS network isolation is claimed. The verification driver uses PATH wrappers as safeguards.',
      'Graph consistency checker is reserved for the eventual candidate audit; it is not independent extraction or kernel checking.']})
inventory={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*'))
    if p.is_file() and 'private-stock' not in p.relative_to(OUT).parts and p.name!='prep-evidence-sha256.json'}
save(OUT/'prep-evidence-sha256.json',inventory)
print(json.dumps({'status':'PREPARATION_PASS','summary':str(OUT/'summary.json'),'tool_sha256':{k:v['sha256'] for k,v in identities.items()}},indent=2),flush=True)
