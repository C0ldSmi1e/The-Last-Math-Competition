#!/usr/bin/env python3
"""Classify separately inventoried compiler artifacts and seal engineering evidence."""
from pathlib import Path
import collections,hashlib,json,re,shutil

OUT=Path('/private/tmp/tlmc4125-independent-engineering')
PRE=Path('/private/tmp/tlmc4125-engineering-review-preflight')
INPUT=Path('/private/tmp/tlmc4125-review-input')
TOOLS=Path('/private/tmp/tlmc4125-engineering-tools')
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1048576),b''):h.update(c)
    return h.hexdigest()
def save(path,value):path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

audit=json.loads((OUT/'declaration-audit.json').read_text())
summary=json.loads((OUT/'summary.json').read_text())
frozen=json.loads((INPUT/'frozen.json').read_text())
safe=[r for r in audit['declarations'] if not r['unsafe']]
runtime=[r for r in audit['declarations'] if r['unsafe']]
graph={n['name']:n for n in audit['dependency_graph']}
safe_closure=set().union(*(set(r['closure']) for r in safe))
runtime_names={r['name'] for r in runtime}
assert len(safe)==80 and len(runtime)==54
assert all(r['trust_enforced'] for r in safe)
assert not safe_closure & runtime_names
assert all(not graph[n]['unsafe'] and graph[n]['kind']!='unavailable' for n in safe_closure)
permitted={'propext','Classical.choice','Quot.sound'}
safe_axioms={n for n in safe_closure if graph[n]['kind']=='axiom'}
assert safe_axioms==permitted
assert not audit['failures']
assert all(r['module']=='Conjecture4125' and not r['trust_enforced'] for r in runtime)
specialized=[r for r in runtime if r['kind']=='axiom']
compiled=[r for r in runtime if r['kind']=='definition']
assert len(specialized)==7 and len(compiled)==47
assert all(re.search(r'\._at\.Conjecture4125\.autGroup\._spec_[1-7]$',r['name']) for r in specialized)
assert all(re.search(r'\._cstage[12]$',r['name']) for r in compiled)
classification=[]
for r in runtime:
    classification.append({'name':r['name'],'originating_module':r['module'],'kind':r['kind'],
        'unsafe':True,'classification':'generated compiler specialization placeholder' if r['kind']=='axiom'
            else 'generated compiler stage definition',
        'reachable_from_any_safe_owned_root':False,'axioms':r['axioms'],
        'unsafe_dependencies':r['unsafe_dependencies'],'type':r['type']})
save(OUT/'runtime-helper-classification.json',{'status':'CLASSIFIED_NOT_PROOF_DEPENDENCIES',
    'count':len(runtime),'compiler_stage_definitions':len(compiled),'specialization_axioms':len(specialized),
    'evidence':['Owned source and configuration were fully read: no authored axiom, unsafe declaration, custom elaborator, macro, or execution hook.',
      'All owned oleans were created by fresh strict compilation from the five frozen source/configuration files; no author olean was copied.',
      'Every helper is attributed to the Conjecture4125 module and matches compiler-stage or specialization names generated while compiling its ordinary definitions.',
      'All 80 safe owned roots and their full exported transitive closures exclude every unsafe/helper node and every nonstandard axiom.',
      'The original full audit is retained, including runtime-only lcProof, specialization and erased-type findings. These findings have not been relabeled as mathematical dependencies.'],
    'safe_root_count':len(safe),'safe_closure_count':len(safe_closure),'safe_closure_axioms':sorted(safe_axioms),
    'safe_runtime_intersection':[],'rows':classification,
    'limits':['Classification concerns ordinary compiler artifacts produced by the supplied trusted Lean runtime; the runtime was not bootstrapped.',
      'There are unsafe runtime declarations in the overall imported environment. The verified claim is their complete absence from mathematical proof dependencies.']})

# Validate recorded command evidence and exact frozen bytes once more.
receipts=[]
for folder in [OUT/'receipts',OUT/'graph-controls']:
    pattern='*.receipt.json' if folder.name=='graph-controls' else '*.json'
    for p in sorted(folder.glob(pattern)):
        r=json.loads(p.read_text())
        stem=p.name.removesuffix('.receipt.json') if folder.name=='graph-controls' else p.stem
        assert sha(folder/(stem+'.stdout'))==r['stdout_sha256']
        assert sha(folder/(stem+'.stderr'))==r['stderr_sha256']
        code=r.get('returncode',r.get('exit_code'))
        nonzero=r.get('expected_rejected',False) or r.get('expected_exit')=='nonzero'
        assert (code!=0 if nonzero else code==0)
        receipts.append(str(p.relative_to(OUT)))
for name,digest in frozen['files'].items():assert sha(INPUT/name)==digest
assert sha(INPUT/'frozen.json')==summary['frozen_manifest_sha256']
for name,digest in summary['expected_pins'].items():
    assert sha(Path('/private/tmp/tlmc4125-engineering-prep/expected-pins')/name)==digest
    assert sha(INPUT/name)==digest
runtime_ids=json.loads((OUT/'runtime-identities.json').read_text())
assert all(sha(Path(p))==digest for p,digest in runtime_ids.items())
tool_ids=json.loads(Path('/private/tmp/tlmc4125-engineering-prep/tool-identities.json').read_text())
assert all(sha(TOOLS/name)==r['sha256'] for name,r in tool_ids.items())
assert json.loads((OUT/'graph-controls/summary.json').read_text())['status']=='PASS'
assert json.loads((PRE/'source-side-effect-review.json').read_text())['status']=='PASS'
assert json.loads((OUT/'active-source-token-audit.json').read_text())==[]
assert all(row['unchanged'] for row in json.loads((OUT/'stock-index-stability.json').read_text()))
save(OUT/'receipt-validation.json',{'status':'PASS','receipts_checked':len(receipts),'receipts':receipts,
    'frozen_bytes_unchanged':True,'runtime_identity_hashes_unchanged':True,'tool_bytes_unchanged':True})
capstones={r['name']:{'kind':r['kind'],'type':r['type'],'axioms':r['axioms'],
    'unsafe_dependencies':r['unsafe_dependencies'],'closure_size':len(r['closure'])}
    for r in safe if r['name'] in frozen['capstones']}
assert len(capstones)==9
save(OUT/'capstone-summary.json',capstones)
verdict={'status':'PASS','scope':'Independent engineering verification of frozen source and dependency trust; mathematical semantic and PDF review are separate.',
    'frozen_manifest_sha256':summary['frozen_manifest_sha256'],'original_driver_status':summary['status'],
    'runtime_helper_classification':'CLASSIFIED_NOT_PROOF_DEPENDENCIES','fresh_strict_lake_build':'PASS',
    'strict_direct_source_replay':['Conjecture4125.lean','Verification.lean'],
    'owned_declarations':134,'safe_mathematical_declarations':80,'safe_closure_declarations':len(safe_closure),
    'compiler_runtime_declarations':54,'total_closure_declarations':28481,'resolved_imports':4056,
    'capstones_checked':9,'permitted_mathematical_axioms':sorted(permitted),'forbidden_proof_dependencies':[],
    'source_side_effect_review':'PASS','full_graph_checker':'PASS','negative_graph_controls':5,
    'operational_controls':6,'hardening_controls':7,'cache_repairs':0,'failed_candidate_runs':0,
    'verification_module_note':'Verification.lean has zero exported declarations; its anonymous examples and nine print-axioms checks were all freshly compiled with warnings treated as errors.',
    'validated_command_receipts':len(receipts),'auxiliary_finite_code_review_and_replay':'PASS',
    'limits':summary['limits']}
save(OUT/'engineering-verdict.json',verdict)
print(json.dumps(verdict,indent=2))
