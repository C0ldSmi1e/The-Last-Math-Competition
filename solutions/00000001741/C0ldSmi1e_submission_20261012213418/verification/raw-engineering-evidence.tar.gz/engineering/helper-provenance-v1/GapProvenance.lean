import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Mathlib.Analysis.SpecialFunctions.Sqrt
import Mathlib.Data.Set.Finite.Lattice
import Mathlib.Tactic

namespace EngineeringGapFixture
def gap (x y : ℕ) : ℝ := |(x : ℝ) ^ 3 - (y : ℝ) ^ 2|
end EngineeringGapFixture
