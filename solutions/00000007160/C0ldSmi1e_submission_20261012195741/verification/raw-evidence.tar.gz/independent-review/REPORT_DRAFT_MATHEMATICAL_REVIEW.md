# Independent working-report mathematical review — 00000007160

Stage: full reading of the working mathematical report, before receipt of frozen author Lean sources. This updates the evidence history; earlier statements that no author report had been read were accurate for the preliminary stage only. No author Lean source has yet been inspected.

Reviewed all 167 lines of `report/report.tex`, SHA-256:

    32bcf04ac091a3fbdeb5e410012bb421c2fbb441c030432b2ece92d0797ed04b

The exact reviewed bytes are retained in `report-draft-reviewed.tex`; `REPORT_DRAFT_READ_MANIFEST.json` records the source and snapshot hashes. No report edits were made. No previous competition submissions, competing proofs, root/selector notes, sessions, or neighboring problems were read.

## Finding

No mathematical error or substantive mismatch with either original language was found. The report gives a valid conventional mathematical proof of the proposed finite-dimensional complex Hoffman–Wielandt inequality, using the standard self-adjoint spectral theorem, characteristic-polynomial invariance under change of basis, Parseval's identity, and finite Birkhoff theorem. Those standard ingredients must be supplied by proved declarations or appropriate library theorems in the final Lean development; this reading does not establish that they have been formalized.

The draft prominently and accurately labels formal verification as pending (lines 17, 24–25, and 149–154). It is not a complete submission or a verified Lean solution at this stage.

## Full argument audit

Lines 1–26: the title, abstract, and working-draft status describe the same mathematical target developed below. There is no completed-verification claim.

Lines 28–50: the original English sentence is quoted accurately, and both original languages do name Hoffman–Wielandt. The original omission of a spectral metric is disclosed. Complete eigenvalue lists are defined through the characteristic polynomial, so algebraic multiplicities are retained. The optimal Euclidean matching distance is a minimum over a finite nonempty permutation set, including the empty dimension. Relabeling either list induces a bijection on permutations; the multiset interpretation is correct. Restricting the intended Lipschitz meaning to the pairwise inequality avoids an unsupported claim of a global consistent labeling.

Lines 52–65: the displayed theorem has both normality hypotheses, the same arbitrary finite size, complete spectra, an actual permutation, unnormalized entrywise Frobenius square, and constant 1. Repeated, nonreal, and zero eigenvalues and noncommuting pairs are included. Real normal matrices embed in the complex domain. The empty dimension is vacuous. Equality at n = 1 establishes that a constant uniform over positive dimensions cannot be less than 1. If desired, the sharpness sentence could be made explicit for every fixed n ≥ 1 by citing A = 0 and B = I_n, which also attain equality. This is optional clarification, not a defect in the stated uniform theorem.

Lines 67–78: H = (T + T*)/2 and K = (T − T*)/(2i) are self-adjoint and T = H + iK. Normality implies H and K commute. Hence K preserves each eigenspace of H. On such an invariant subspace its restriction remains self-adjoint for the inherited inner product, so the self-adjoint spectral theorem gives an orthonormal eigenbasis in each summand. Taking their union produces a complete joint orthonormal eigenbasis and therefore eigenvalues a + ib for T. Neither Hermitian T nor a simple spectrum is assumed. The construction has the correct empty-dimensional interpretation.

Lines 80–87: the diagonal form and change-of-basis invariance of the characteristic polynomial give the full product of linear factors. This is the needed bridge from eigenbasis values to complete eigenvalue lists with algebraic multiplicity. Uniqueness of roots with multiplicity over the complex numbers implies any other complete list is a permutation; the report does not infer completeness merely from the existence of separate eigenvectors.

Lines 89–108: the declared convention is conjugate-linear in the first argument and linear in the second. Under that convention the coordinate identity <e_i, Ax> = α_i <e_i, x> is correct because the e basis diagonalizes A. It would not follow from an arbitrary right eigenvector alone, but the complete orthonormal eigenbasis supplies exactly the needed justification. The B eigenvector identity then gives <e_i, (A − B)f_j> = (α_i − β_j)<e_i, f_j>. Both the row and column sums of |<e_i, f_j>|² are 1 by Parseval and conjugate symmetry, so the weight matrix is doubly stochastic.

Lines 109–126: Parseval first gives the weighted squared-distance identity with the sum of ‖(A − B)f_j‖². The detailed basis-invariance calculation is correct: <u_k, Df_j> = <D*u_k, f_j> under the stated convention, Parseval in the f basis gives ‖D*u_k‖², and the components of D*u_k are the conjugates of row k of D. Thus the last double sum is precisely Σ_(k,l)|D_(k,l)|². Every sum is finite. No matrix-norm instance, hidden normalization, or incorrect conjugation enters the argument.

Lines 128–147: Birkhoff's representation uses the orientation j = σ(i), matching the target cost. Distributing the finite sums gives a convex average of the permutation costs. A minimum exists and is at most the average because the coefficients are nonnegative and sum to 1. The nonnegative squared inequality passes correctly through square roots, and relabeling transports it to arbitrary complete eigenvalue lists. Dimension zero can be handled directly as already noted; the displayed Birkhoff representation also has its trivial extension with weight 1 on the unique empty permutation.

Lines 149–165: the pending source correspondence, strict rebuild, axiom audit, and full review are clearly stated. The auxiliary-check coverage and all reported counts match the independently replayed checker. “Four additional semantic controls” is the accurate description, including the multiplicity control. The text correctly denies that the finite examples establish the universal theorem. The 71 probes are implementation checks rather than mathematical generalization.

Lines 166–167: the document closes normally; no additional mathematical claim is omitted from this reading.

## Remaining final-review duties

The report's mathematical validity alone does not certify the final package. On receipt of frozen Lean sources, check the actual quantified domain and assumptions; normality-to-eigenbasis construction; complete algebraic-multiplicity characterization; exact weighted Frobenius identity; permutation and Birkhoff orientation; arbitrary spectral-list transport; square-root and minimum-distance conclusion; empty dimension; proof dependencies and axioms; and the source-to-report correspondence. Independently compile the complete project and inspect every supplied auxiliary artifact. A PDF visual inspection and reproduction of its final source are also not part of this draft-only mathematical review.
