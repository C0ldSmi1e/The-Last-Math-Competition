#!/bin/sh
set -eu
cd /Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work
python3 -I -B 7160/python-hardening-review/run_python_hardening.py > 7160/python-hardening-review/run-output.txt 2>&1
cat 7160/python-hardening-review/run-output.txt
