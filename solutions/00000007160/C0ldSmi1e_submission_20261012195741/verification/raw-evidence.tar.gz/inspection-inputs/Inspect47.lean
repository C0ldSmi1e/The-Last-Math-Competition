import Frobenius
import HoffmanWielandt
import Matching
import NormalSpectral
import Reindexing
import Verification
import Verification.ClosureAudit
#audit_kernel_modules [Frobenius, HoffmanWielandt, Matching, NormalSpectral, Reindexing, Verification] "declaration-audit.json"
