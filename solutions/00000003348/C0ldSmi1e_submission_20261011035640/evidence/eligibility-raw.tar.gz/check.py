#!/usr/bin/env python3
"""Bounded metadata-only candidate 3348 duplicate screen; no proof contents."""
import ast,csv,datetime,hashlib,json,pathlib,re,subprocess,sys,time,urllib.parse
from types import SimpleNamespace
P=pathlib.Path('/private/tmp/tlmc3348-eligibility-final')
sys.path.insert(0,'/private/tmp/tlmc-operational-toolkit-after407')
import evidence as t

def take(path,names):
 s=pathlib.Path(path).read_text()
 exec('\n\n'.join(ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in names),globals())
def require(k,v):
 if not v:raise RuntimeError(k)
def save(name,value):
 p=P/name
 require('no overwrite '+name,not p.exists())
 p.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')

take('/private/tmp/tlmc1624-author-eligibility/capture.py',{'ReliableEvidence','matches','context','pproj','iproj'})
take('/private/tmp/tlmc1568-eligibility/early-check.py',{'BoundedEvidence'})
R=t.REPO
main='9b795e7a94a6076e49a65a6489e1caf9153abd23'
source='/private/tmp/tlmc3348-clean-author-input/original.md'
source_hash='4c5b2b9cd847d97c48db0bf930fdcbb4c5ac5edc8cd2b05ac0ec362c73fc7232'
base=pathlib.Path('/private/tmp/tlmc-next-neutral-after105-refresh/capture/current-neutral-snapshot.json')
terms=['Julia','expansive','uniformly expanding','Cantor','pressure equation','一致扩张','康托尔','压力方程']
patterns=[r'\bJulia\b',r'\bexpansive\b',r'uniformly[\s_-]+expanding',r'\bCantor\b',r'pressure[\s_-]+equations?','一致扩张','康托尔','压力方程']
queries=[{'name':'canonical','query':'repo:'+R+' "3348" in:title,body,comments'}, {'name':'padded','query':'repo:'+R+' "00000003348" in:title,body,comments'}, {'name':'path','query':'repo:'+R+' "solutions/00000003348" in:title,body,comments'}, {'name':'title','query':'repo:'+R+' 3348 in:title'}]+[{'name':'topic-'+str(i),'query':'repo:'+R+' "'+term+'" in:title,body,comments'} for i,term in enumerate(terms)]
old=t.load('/private/tmp/tlmc1568-eligibility/candidate-config.prepared.json')
bindings=[dict(x) for x in old['identity_bindings'] if x['role']!='source']
b=pathlib.Path(source).read_bytes();require('exact candidate source hash',t.digest(b)==source_hash)
bindings.insert(0,{'role':'source','path':source,'repository_path':'conjectures/00000003348.md','sha256':source_hash,'git_blob_sha':t.git_blob(b)})
for x in bindings:require('binding hash '+x['role'],t.digest(pathlib.Path(x['path']).read_bytes())==x['sha256'])
cfg={'candidate_id':'00000003348','candidate_path':'solutions/00000003348','main_sha':main,'tree_sha':old['tree_sha'],'source_topic_terms':terms,'source_topic_patterns':patterns,'identity_bindings':bindings,'search_queries':queries,'max_actual_requests':30,'max_elapsed_seconds':120,'baseline_path':str(base),'baseline_sha256':t.digest(base.read_bytes()),'since':'2026-10-11T03:22:20Z','candidate_absence_imported':False,'scope':'Current upstream path and paginated same-path commit API history; complete retained neutral catalog metadata plus bounded updated metadata and repository issue searches. No fork or full DAG history claim.'}
save('config.json',cfg)
C=SimpleNamespace(candidate_path=cfg['candidate_path'],numeric_pattern=re.compile(r'(?<![A-Za-z0-9])0*3348(?![A-Za-z0-9])',re.I),topic_pattern=re.compile('|'.join(patterns),re.I))
C.candidate_match=lambda x:bool(C.numeric_pattern.search(x) or C.topic_pattern.search(x))
s=t.load(base);hits=matches(s)
# File paths in retained inline metadata can carry an exact candidate identifier.
for x in s['inline']:
 path=x.get('path') or ''
 if C.numeric_pattern.search(path):hits.append({'number':int(x['pull_request_url'].rsplit('/',1)[1]),'surface':'inline_path:'+str(x['id']),'id_matches':[m.group() for m in C.numeric_pattern.finditer(path)],'topic_matches':[]})
nums=sorted({h['number'] for h in hits})
save('cached-matches.json',hits)
save('cached-lead-contexts.json',[dict(number=n,context=context(s,n)) for n in nums])
save('cached-screen-summary.json',{'baseline_sha256':cfg['baseline_sha256'],'counts':{k:len(s[k]) for k in ['prs','issues','comments','inline','reviews']},'lead_numbers':nums,'matches':len(hits),'classification':'PENDING_ROOT_METADATA_ASSESSMENT','numeric_search_false_positive_policy':'Numeric public issue/PR numbering and formula text are not automatically candidate claims.'})
rows=list(csv.DictReader(pathlib.Path(next(x['path'] for x in bindings if x['role']=='metadata')).open()))
row=[x for x in rows if str(x['id']).lstrip('0')=='3348'];require('one candidate metadata row',len(row)==1);save('candidate-metadata.json',row[0])
# Exact local identity reads print no source or rules bodies.
identities=[]
for x in bindings:
 cmd=['git','--no-optional-locks','-C','/Users/daniel/The-Last-Math-Competition','ls-tree',main,'--',x['repository_path']]
 start=t.utc();pr=subprocess.run(cmd,capture_output=True,timeout=15)
 name='identity-'+x['role'];(P/(name+'.stdout')).write_bytes(pr.stdout);(P/(name+'.stderr')).write_bytes(pr.stderr)
 fields=pr.stdout.decode().split();ok=pr.returncode==0 and len(fields)>=4 and fields[2]==x['git_blob_sha']
 identities.append({'role':x['role'],'command':cmd,'started_at':start,'completed_at':t.utc(),'exit_code':pr.returncode,'stdout_sha256':t.digest(pr.stdout),'stderr_sha256':t.digest(pr.stderr),'exact_blob_match':ok})
 require('same-main identity '+x['role'],ok)
save('source-rules-metadata-identities.json',identities)
operative=[]
for suffix,role,start,end in [('en','english_rules','## Rules\n','## Leaderboard\n'),('zh-CN','chinese_rules','## 比赛规则\n','## 排行榜（Leaderboard）\n')]:
 raw=pathlib.Path(next(x['path'] for x in bindings if x['role']==role)).read_text();require('unique rules delimiters '+role,raw.count(start)==1 and raw.count(end)==1)
 exact=((start+raw.split(start,1)[1].split(end,1)[0]).strip()+'\n').encode();path=pathlib.Path('/private/tmp/tlmc3348-clean-author-input')/('RULES.'+suffix+'.md');require('clean current operative rules '+role,path.read_bytes()==exact)
 operative.append({'role':role,'path':str(path),'sha256':t.digest(exact),'equal_to_same_main_readme_rules_section':True})
save('clean-operative-rule-identities.json',operative)

E=BoundedEvidence(P/'capture',allow_network=True)
result={'status':'HOLD_INCOMPLETE','candidate_id':cfg['candidate_id'],'main_sha':main,'source_rules_metadata_identity_same_commit':True,'scope':cfg['scope'],'cached_lead_numbers':nums,'classification':'PENDING_ROOT_METADATA_ASSESSMENT'}
try:
 current,_=E.get('main-start.json','repos/'+R+'/git/ref/heads/main');require('upstream main unchanged',current and current['object']['sha']==main)
 tip=t.inspect_tip(E,C,R,main,'main-candidate/')
 require('candidate current main path absent and same-path history empty',tip['pass'])
 search_summary=[]
 for q in queries:
  items=E.pages('search/'+q['name']+'.json','search/issues?'+urllib.parse.urlencode({'q':q['query'],'per_page':100}),key='items')
  search_summary.append({**q,'numbers':[x['number'] for x in items],'total':len(items)})
 E.save('search-summary.json',search_summary)
 deltas={}
 for key,endpoint in [('issues','issues?state=all&since='+cfg['since']+'&sort=updated&direction=asc&per_page=100'),('comments','issues/comments?since='+cfg['since']+'&sort=updated&direction=asc&per_page=100'),('inline','pulls/comments?since='+cfg['since']+'&sort=updated&direction=asc&per_page=100')]:
  deltas[key]=E.pages('delta/'+key+'.json','repos/'+R+'/'+endpoint)
 ds={**s,'issues':deltas['issues'],'comments':deltas['comments'],'inline':deltas['inline'],'prs':[],'reviews':[],'discussions':{'items':[],'complete_feedback':{}}}
 E.save('delta/matches.json',matches(ds))
 end,_=E.get('main-end.json','repos/'+R+'/git/ref/heads/main');require('ending upstream main unchanged',end and end['object']['sha']==main)
 require('all requests resolved',not E.unresolved())
 lead_numbers=sorted(set(nums)|{n for q in search_summary for n in q['numbers']}|{x['number'] for x in matches(ds)})
 E.save('all-lead-contexts.json',[{'number':n,'cached_context':context(s,n),'fresh_search_metadata':[x for q in queries for x in t.load(E.path/('search/'+q['name']+'.json')) if x['number']==n],'fresh_issue_metadata':[x for x in deltas['issues'] if x['number']==n],'fresh_comments':[x for x in deltas['comments'] if int(x['issue_url'].rsplit('/',1)[1])==n],'fresh_inline':[x for x in deltas['inline'] if int(x['pull_request_url'].rsplit('/',1)[1])==n]} for n in lead_numbers])
 result.update(status='BOUNDED_METADATA_SCREEN_COMPLETE_PENDING_ROOT_CLASSIFICATION',main_path_history=tip,search_summary=search_summary,all_lead_numbers=lead_numbers,delta_counts={k:len(v) for k,v in deltas.items()},delta_match_count=len(matches(ds)),publication_eligibility_granted=False)
except Exception as ex:result['error']=repr(ex)
finally:
 E.save('request-errors.json',E.errors);E.save('retry-resolutions.json',E.retry_resolutions);E.save('pagination.json',E.pagination)
 result.update(actual_requests=E.counter,elapsed_seconds=time.monotonic()-E.started_monotonic,unresolved_errors=E.unresolved(),observed_through=max((x['completed_at'] for x in E.records),default=None))
 save('result.json',result)
 manifest=[{'path':str(x.relative_to(P)),'sha256':t.digest(x.read_bytes()),'bytes':x.stat().st_size} for x in sorted(P.rglob('*')) if x.is_file() and x.name!='SHA256SUMS.json']
 save('SHA256SUMS.json',manifest)
 print(json.dumps({k:result[k] for k in ['status','actual_requests','elapsed_seconds','cached_lead_numbers','observed_through']}))
 print('all_lead_numbers',result.get('all_lead_numbers'));print('error',result.get('error'))
