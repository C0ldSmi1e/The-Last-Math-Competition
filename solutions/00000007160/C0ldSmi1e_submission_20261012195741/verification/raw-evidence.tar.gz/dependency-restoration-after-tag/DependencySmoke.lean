import Mathlib.Analysis.InnerProductSpace.JointEigenspace
import Mathlib.Analysis.Convex.Birkhoff
import Mathlib.LinearAlgebra.Matrix.Spectrum
import Mathlib.Analysis.InnerProductSpace.Adjoint
import Mathlib.LinearAlgebra.Matrix.Charpoly.Basic
import Mathlib.Analysis.Matrix
import Mathlib.LinearAlgebra.Charpoly.ToMatrix
import Mathlib.Data.Complex.Module
import Mathlib.Tactic

-- Generic module availability smoke; no candidate declarations.
example : True := True.intro
