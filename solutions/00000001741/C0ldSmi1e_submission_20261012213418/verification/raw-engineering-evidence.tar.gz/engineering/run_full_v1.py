#!/usr/bin/env python3
"""Execute frozen Lean engineering checks; retain every command and failure."""
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

D=Path('/Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work')
E=D/'1741/engineering'
AUTHOR=D/'1741/author'
FROZEN=D/'1741/frozen-v1.json'
TOOLS=D/'verification-tools'
STOCK=D/'runtime/stock1925'
LEAN=D/'runtime/lean-4.19.0-darwin_aarch64/bin'
OUT=E/'full-v1'
AUX=E/'author-verifier-v1'
HARD=E/'hardening-v1'
RECEIPTS=E/'full-v1-command-receipts'

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()

def save(p,data):
    p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

assert not any(p.exists() for p in (OUT,AUX,HARD,RECEIPTS))
RECEIPTS.mkdir()
AUX.mkdir()
manifest=json.loads(FROZEN.read_text())
for name,digest in manifest['files'].items():
    assert sha(AUTHOR/name)==digest
    dest=AUX/name
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(AUTHOR/name,dest)
assert not any(AUX.rglob('*.olean'))
env=dict(os.environ)
for key in list(env):
    if key in ('LEAN_PATH','LEAN_SRC_PATH','LEAN_SYSROOT','LAKE_HOME') or key.startswith('GIT_'):
        del env[key]
env['GIT_OPTIONAL_LOCKS']='0'
env['GIT_NO_REPLACE_OBJECTS']='1'
env['PATH']=str(LEAN)+':'+env.get('PATH','')
identities={str(p):sha(p) for p in (Path(__file__),FROZEN,TOOLS/'verify.py',TOOLS/'check_audit_graph.py',TOOLS/'test_hardening.py',TOOLS/'templates/ClosureAudit.lean.txt',AUTHOR/'verify.py')}
save(E/'full-v1-orchestration-identities.json',identities)

def run(name,argv,cwd):
    prefix=RECEIPTS/name
    start=time.time()
    print('Starting '+name,flush=True)
    with prefix.with_suffix('.stdout').open('wb') as stdout, prefix.with_suffix('.stderr').open('wb') as stderr:
        result=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,stdout=stdout,stderr=stderr)
    record={'argv':list(map(str,argv)),'cwd':str(cwd),'exit_code':result.returncode,'seconds':time.time()-start,
            'environment':{k:env[k] for k in ('PATH','GIT_OPTIONAL_LOCKS','GIT_NO_REPLACE_OBJECTS')},
            'stdout_sha256':sha(prefix.with_suffix('.stdout')),'stderr_sha256':sha(prefix.with_suffix('.stderr'))}
    save(prefix.with_suffix('.json'),record)
    print(name+': exit '+str(result.returncode),flush=True)
    return record

with ThreadPoolExecutor(max_workers=3) as pool:
    full=pool.submit(run,'full-verifier',[sys.executable,TOOLS/'verify.py','verify',AUTHOR,FROZEN,STOCK,LEAN,OUT,D/'1741/clean-author-input'],E)
    aux=pool.submit(run,'author-verifier',[sys.executable,AUX/'verify.py','--runtime-root',D/'runtime'],AUX)
    hard=pool.submit(run,'hardening',[sys.executable,TOOLS/'test_hardening.py',HARD],E)
    results={'full-verifier':full.result(),'author-verifier':aux.result(),'hardening':hard.result()}
if results['full-verifier']['exit_code']==0:
    results['graph-check']=run('graph-check',[sys.executable,TOOLS/'check_audit_graph.py',OUT/'declaration-audit.json'],E)
for name,digest in manifest['files'].items():
    assert sha(AUTHOR/name)==digest, ('Original frozen input changed',name)
    assert sha(AUX/name)==digest, ('Private auxiliary frozen input changed',name)
assert all(sha(Path(p))==digest for p,digest in identities.items())
save(E/'full-v1-orchestration-results.json',{
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status':'COMMANDS_PASS_PENDING_ENGINEERING_REVIEW' if all(r['exit_code']==0 for r in results.values()) else 'RETAINED_COMMAND_FAILURE',
    'results':results,'frozen_original_and_private_source_unchanged':True,
    'scope':'Command execution only; full engineering verdict and runtime-helper classification are separate.'})
raise SystemExit(0 if all(r['exit_code']==0 for r in results.values()) else 1)
