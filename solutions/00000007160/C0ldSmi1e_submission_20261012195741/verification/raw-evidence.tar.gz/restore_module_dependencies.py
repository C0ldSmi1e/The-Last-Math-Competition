#!/usr/bin/env python3
"""Restore exact requested pinned generic modules into a new private stock clone.
Never reads a competition statement or proof. The only network operation is the
pinned upstream cache tool's get command (including its ProofWidgets release).
"""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parents[1]
RUNTIME=BASE/'runtime'
SHARED=RUNTIME/'stock/mathlib'
PRIVATE=RUNTIME/'stock7160'
CACHE=RUNTIME/'cache7160'
BIN=RUNTIME/'lean-4.19.0-darwin_aarch64/bin'
OUT=BASE/'7160/dependency-restoration'
MODULES=[
 'Mathlib.Analysis.InnerProductSpace.JointEigenspace',
 'Mathlib.Analysis.Convex.Birkhoff',
 'Mathlib.LinearAlgebra.Matrix.Spectrum',
 'Mathlib.Analysis.InnerProductSpace.Adjoint',
 'Mathlib.LinearAlgebra.Matrix.Charpoly.Basic',
 'Mathlib.Analysis.Matrix',
 'Mathlib.LinearAlgebra.Charpoly.ToMatrix',
 'Mathlib.Data.Complex.Module',
 'Mathlib.Tactic']

def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def require(ok,msg):
    if not ok:raise RuntimeError(msg)
def packages(root):
    return [('mathlib',root)]+[(p.name,p) for p in sorted((root/'.lake/packages').iterdir()) if p.is_dir()]
def oleans(root):
    return {name+':'+str(p.relative_to(r)):sha(p) for name,r in packages(root) for p in sorted((r/'.lake/build/lib/lean').rglob('*.olean'))}
def indexes(root):return {n:sha(r/'.git/index') for n,r in packages(root)}
def archive_inventory(root):return {p.name:sha(p) for p in sorted(root.glob('*.ltar'))}

def main():
    global OUT
    resume=sys.argv[1:]==['--resume-after-tag']
    require(not sys.argv[1:] or resume,'Unsupported arguments')
    prior=OUT
    if resume:
        OUT=BASE/'7160/dependency-restoration-after-tag'
        require(PRIVATE.is_dir() and CACHE.is_dir() and (prior/'summary.json').is_file(),'Missing retained failed attempt')
        require(json.loads((prior/'summary.json').read_text())['status']=='FAIL','Expected prior failure')
    else:
        require(not PRIVATE.exists() and not CACHE.exists(),'Stock/cache outputs must be new')
    require(not OUT.exists(),'Receipt output must be new')
    OUT.mkdir(parents=True)
    (OUT/'receipts').mkdir()
    shutil.copy2(__file__,OUT/'driver.py.txt')
    env=os.environ.copy()
    for key in list(env):
        if key.startswith('GIT_') or key in ['LEAN_PATH','LEAN_SRC_PATH','LEAN_SYSROOT','LAKE_HOME','PYTHONOPTIMIZE']:env.pop(key,None)
    env.update(PATH=str(BIN)+os.pathsep+env.get('PATH',''), MATHLIB_CACHE_DIR=str(CACHE),
               GIT_OPTIONAL_LOCKS='0',GIT_NO_REPLACE_OBJECTS='1',PYTHONDONTWRITEBYTECODE='1')
    counter=0
    def run(argv,cwd=PRIVATE,expected=0):
        nonlocal counter
        counter+=1
        prefix=OUT/'receipts'/f'{counter:03d}'
        started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
        with prefix.with_suffix('.stdout').open('wb') as so,prefix.with_suffix('.stderr').open('wb') as se:
            r=subprocess.run(list(map(str,argv)),cwd=cwd,env=env,stdout=so,stderr=se)
        save(prefix.with_suffix('.json'),{'argv':list(map(str,argv)),'cwd':str(cwd),'started_utc':started,
             'elapsed_seconds':time.monotonic()-t,'exit_code':r.returncode,'expected_exit':expected,
             'stdout_sha256':sha(prefix.with_suffix('.stdout')),'stderr_sha256':sha(prefix.with_suffix('.stderr')),
             'environment_overrides':{k:env[k] for k in ['PATH','MATHLIB_CACHE_DIR','GIT_OPTIONAL_LOCKS','GIT_NO_REPLACE_OBJECTS','PYTHONDONTWRITEBYTECODE']}})
        print(f'{counter}: exit {r.returncode}: {argv}',flush=True)
        require(r.returncode==expected,'Unexpected exit, see '+str(prefix))
        return prefix.with_suffix('.stdout').read_text()
    summary={'status':'RUNNING','scope':'Generic pinned dependency engineering only; no competition mathematics read',
             'modules':MODULES,'shared_stock':str(SHARED),'private_stock':str(PRIVATE),'private_cache':str(CACHE),
             'cache_url':'https://lakecache.blob.core.windows.net/mathlib4/f/'}
    shared_before=oleans(SHARED);indexes_before=indexes(SHARED)
    save(OUT/'shared-olean-before.json',shared_before);save(OUT/'shared-index-before.json',indexes_before)
    runtime_before={str(p):sha(p) for p in [BIN/'lean',BIN/'lake',*(BIN.parent/'lib/lean').glob('*.dylib')]}
    save(OUT/'runtime-before.json',runtime_before)
    try:
        if resume:
            summary['resumes_preserved_failed_summary_sha256']=sha(prior/'summary.json')
            tag=run(['/usr/bin/git','rev-parse','v0.0.57^{}'],cwd=PRIVATE/'.lake/packages/proofwidgets').strip()
            head=run(['/usr/bin/git','rev-parse','HEAD'],cwd=PRIVATE/'.lake/packages/proofwidgets').strip()
            require(tag==head=='c4919189477c3221e6a204008998b0d724f49904','Restored tag is not pinned commit')
            summary['proofwidgets_release_tag']={'tag':'v0.0.57','resolved_commit':tag,'head':head}
        else:
            run(['/bin/cp','-cR',str(SHARED)+'/.',PRIVATE],cwd=RUNTIME)
            run(['/bin/cp','-cR',RUNTIME/'local-cache',CACHE],cwd=RUNTIME)
        before=oleans(PRIVATE);cache_before=archive_inventory(CACHE)
        require(before==shared_before,'Private stock clone differs')
        save(OUT/'private-olean-before.json',before);save(OUT/'cache-archive-before.json',cache_before)
        save(OUT/'private-index-before.json',indexes(PRIVATE))
        source_files=['Cache/Main.lean','Cache/Requests.lean','Cache/Hashing.lean','Cache/IO.lean','Cache/Lean.lean','lean-toolchain','lake-manifest.json','lakefile.lean']
        save(OUT/'cache-tool-source-identities.json',{p:sha(PRIVATE/p) for p in source_files})
        run([BIN/'lake','env','lean','--run','Cache/Main.lean','get',*MODULES])
        smoke=OUT/'DependencySmoke.lean'
        smoke.write_text(''.join('import '+m+'\n' for m in MODULES)+'\n-- Generic module availability smoke; no candidate declarations.\nexample : True := True.intro\n')
        run([BIN/'lake','env','lean','-DwarningAsError=true','--root='+str(OUT),smoke])
        pin_dir=BASE/'3992/recovery-tool-review/source-snapshots/recovered-author'
        validator=BASE/'3992/recovery-tool-review/check_stock_pins.py'
        run(['/usr/bin/python3','-B',validator,PRIVATE,pin_dir,OUT/'private-source-validation'],cwd=BASE)
        for name,root in packages(PRIVATE):
            status=run(['/usr/bin/git','--no-optional-locks','-c','core.fsmonitor=false','status','--porcelain','--untracked-files=no'],cwd=root)
            require(not status.strip(),'Private tracked files changed: '+name)
        after=oleans(PRIVATE);cache_after=archive_inventory(CACHE)
        save(OUT/'private-olean-after.json',after);save(OUT/'cache-archive-after.json',cache_after)
        save(OUT/'private-index-after.json',indexes(PRIVATE))
        changed={p:{'before':before[p],'after':after[p]} for p in before.keys()&after.keys() if before[p]!=after[p]}
        added={p:after[p] for p in after.keys()-before.keys()}
        removed={p:before[p] for p in before.keys()-after.keys()}
        save(OUT/'private-olean-delta.json',{'added':added,'changed':changed,'removed':removed})
        save(OUT/'cache-archive-delta.json',{'added':{p:cache_after[p] for p in cache_after.keys()-cache_before.keys()},'changed':{p:{'before':cache_before[p],'after':cache_after[p]} for p in cache_before.keys()&cache_after.keys() if cache_before[p]!=cache_after[p]},'removed':{p:cache_before[p] for p in cache_before.keys()-cache_after.keys()}})
        require(oleans(SHARED)==shared_before,'Shared cache changed')
        require(indexes(SHARED)==indexes_before,'Shared indexes changed')
        for p,digest in runtime_before.items():require(sha(Path(p))==digest,'Runtime changed')
        # Compare shared tracked source bytes against the validated cloned stock.
        source_validation=json.loads((OUT/'private-source-validation/summary.json').read_text())
        require(source_validation['status']=='PASS','Source validation failed')
        for spec in source_validation['packages']:
            root=SHARED if spec['name']=='mathlib' else SHARED/'.lake/packages'/spec['name']
            for row in json.loads((OUT/'private-source-validation'/(spec['name']+'-tracked.json')).read_text()):
                p=root/row['path'];digest=hashlib.sha256(os.fsencode(os.readlink(p))).hexdigest() if p.is_symlink() else sha(p)
                require(digest==row['sha256'],'Shared tracked source differs: '+str(p))
        summary.update(status='PASS',private_olean_count_before=len(before),private_olean_count_after=len(after),
                       added_oleans=len(added),changed_oleans=len(changed),removed_oleans=len(removed),
                       newly_downloaded_archives=len(cache_after.keys()-cache_before.keys()),
                       shared_cache_source_indexes_unchanged=True,runtime_unchanged=True,
                       private_index_bytes_unchanged=json.loads((OUT/'private-index-before.json').read_text())==indexes(PRIVATE),
                       smoke_sha256=sha(smoke),raw_command_receipts=counter,
                       limits=['Pinned official cache artifacts are hash-recorded, not independently authenticated or rebuilt',
                               'Supplied Lean runtime was not bootstrapped',
                               'Strict smoke confirms the exact module imports, not a candidate mathematical claim'])
    except Exception as e:
        summary.update(status='FAIL',error=repr(e));raise
    finally:
        summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        save(OUT/'summary.json',summary);print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__':main()
