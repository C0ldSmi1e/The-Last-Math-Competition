#!/usr/bin/env python3
"""Finalize the exact candidate's engineering evidence without rerunning proofs.
Validates records, classifies compiler helpers, and checks all safe root closures.
"""
import collections,datetime,hashlib,json,re,shutil
from pathlib import Path
P=Path(__file__).resolve().parent;D=P.parent;R=P/'engineering-review-v1';O=P/'engineering-finalization-v1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def req(v,m):
 if not v:raise RuntimeError(m)
def receipt(p,expected=None):
 x=read(p)
 if p.name=='receipt.json':so=p.parent/'stdout.txt';se=p.parent/'stderr.txt'
 else:so=p.with_suffix('.stdout');se=p.with_suffix('.stderr')
 req(sha(so)==x['stdout_sha256'] and sha(se)==x['stderr_sha256'],'Output hash: '+str(p))
 exp=expected if expected is not None else x['expected_exit']
 req(x['exit_code']!=0 if exp=='nonzero' else x['exit_code']==exp,'Exit: '+str(p))
 return {'path':str(p.relative_to(P)),'sha256':sha(p),'exit_code':x['exit_code'],'expected_exit':exp,'stdout_sha256':sha(so),'stderr_sha256':sha(se)}

def main():
 req(not O.exists(),'Output must be fresh');O.mkdir();(O/'driver.py.txt').write_bytes(Path(__file__).read_bytes())
 summary={'status':'RUNNING','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 try:
  frozen=P/'frozen-v1.json';f=read(frozen);req(sha(frozen)=='bf918649c77eaa562ecd36add9416f6a02957bd56813c45fb539691945c96b2e','Wrong freeze')
  s=read(R/'summary.json');data=read(R/'declaration-audit.json');helpers=read(R/'runtime-helper-inventory.json')
  req(s['status']=='PASS_PENDING_RUNTIME_HELPER_CLASSIFICATION','Unexpected verifier status')
  req(not data['failures'] and data['strict_dependency_policy'] and not data['kernel_check_performed'],'Invalid audit state')
  roots={x['name']:x for x in data['declarations']};graph={x['name']:x for x in data['dependency_graph']};safe={n:x for n,x in roots.items() if not x['unsafe']};unsafe={n:x for n,x in roots.items() if x['unsafe']}
  req(len(roots)==96 and len(safe)==74 and len(unsafe)==22 and len(graph)==20672,'Unexpected declaration counts')
  req({x['name'] for x in helpers}==set(unsafe),'Helper inventory does not cover every unsafe root')
  req(set(data['requested_modules'])==set(s['modules']),'Module coverage mismatch')
  req(set(f['capstones'])==set(s['capstones']) and all(n in safe for n in f['capstones']),'Capstone coverage mismatch')
  graph_report=read(P/'graph-consistency-v1-command/stdout.txt');req(graph_report['status']=='PASS' and graph_report['roots']==96 and graph_report['graph_nodes']==20672,'Graph consistency missing')
  receipts=[receipt(p) for p in sorted((R/'receipts').glob('*.json'))];req(len(receipts)==61,'Missing verifier receipts')
  receipts += [receipt(P/'engineering-review-v1-command/receipt.json',0),receipt(P/'graph-consistency-v1-command/receipt.json',0),receipt(P/'runtime-helper-review-v1/receipt.json',1),receipt(P/'runtime-helper-review-v2/receipt.json',0)]
  for d in ['compiler-provenance-v1-command','compiler-source-provenance-v1-command','compiler-stage-provenance-v1-command']:receipts.append(receipt(P/d/'receipt.json',0))
  req("unknown option 'pp.width'" in (P/'runtime-helper-review-v1/stdout.txt').read_text(),'Unexpected failed probe reason')
  req((P/'runtime-helper-review-v2/stderr.txt').read_bytes()==b'','Helper probe stderr')
  printed=re.findall(r'^unsafe (?:def|axiom) ([^ :\n]+)',(P/'runtime-helper-review-v2/stdout.txt').read_text(),re.M)
  req(len(printed)==22 and set(printed)==set(unsafe),'Printed helper coverage mismatch')
  groups={}
  def group(base,names,category,reason):
   for suffix in names:groups['Conjecture1925.'+base+suffix]={'category':category,'review':reason}
  group('base',['._cstage1','._cstage2'],'compiler stage cache','Computes the zero element in the indexed finite cyclic component.')
  group('cycleLength',['._cstage1','._cstage2'],'compiler stage cache','Natural addition, power, and multiplication implementing the authored cycle length.')
  group('observable',['._cstage1','._cstage2'],'compiler stage cache','Natural threshold comparison and zero/one branches implementing the authored observable.')
  group('squareTime',['._cstage1','._cstage2'],'compiler stage cache','Natural squaring implementing the authored polynomial time.')
  group('instMeasurableSpaceΩ',['._cstage1','._cstage2','._closed_1._cstage2'],'compiler stage and closed-term cache','Complete-lattice top measurable-space value and its cached implementation.')
  group('rotation',['._cstage1','._cstage2','._closed_1._cstage2','._closed_2._cstage2','._closed_3._cstage2'],'compiler stage and closed-term cache','Equivalence record containing the forward/inverse functions; runtime proof fields erased. Graph records lcProof and runtime sentinels explicitly.')
  for i,direction in [(1,'inverse: subtraction by one'),(2,'forward: addition by one')]:
   group('rotation._elambda_'+str(i),[''],'unsafe lifted-lambda placeholder','Compiler-generated unsafe axiom for '+direction+'; compiled implementation is preserved in corresponding stage declarations.')
   group('rotation._elambda_'+str(i),['._cstage1','._cstage2'],'lifted-lambda compiler stage cache','Compiled body of '+direction+' on the same cycle, corroborating the frozen rotation definition.')
  req(set(groups)==set(unsafe),'Unexpected helper family')
  sentinels={'_obj','_neutral','lcProof','lcCast','lcErased','lcAny','lcUnreachable','sorryAx','Lean.ofReduceBool','Lean.trustCompiler'}
  permitted={'propext','Classical.choice','Quot.sound'};safe_checks=[];safe_union=set()
  # Baseline checker independently recomputed closures; here retain explicit per-root exclusions.
  for name,root in sorted(safe.items()):
   req(root['trust_enforced'],'Safe root not trust-enforced: '+name)
   closure=set(root['closure']);safe_union|=closure
   req(not closure.intersection(unsafe),'Safe root reaches generated unsafe helper: '+name)
   req(not closure.intersection(sentinels),'Safe root reaches runtime sentinel: '+name)
   req(all(n in graph and graph[n]['kind']!='unavailable' and not graph[n]['unsafe'] for n in closure),'Unsafe/missing safe dependency: '+name)
   req(set(root['axioms'])<=permitted and not root['unsafe_dependencies'],'Trust mismatch: '+name)
   safe_checks.append({'name':name,'module':root['module'],'kind':root['kind'],'closure_size':len(closure),'closure_list_sha256':hashlib.sha256(json.dumps(sorted(closure),separators=(',',':')).encode()).hexdigest(),'unsafe_helper_intersection':[],'runtime_sentinel_intersection':[],'unsafe_or_missing_nodes':[],'axioms':root['axioms'],'generated_closed_name':'._closed_' in name})
  helper_rows=[{'name':n,'module':unsafe[n]['module'],'kind':unsafe[n]['kind'],'unsafe':True,'type':unsafe[n]['type'],'body_dependencies':unsafe[n]['body_dependencies'],'runtime_axioms':unsafe[n]['axioms'],'reachable_from_safe_roots':[],**groups[n]} for n in sorted(unsafe)]
  save(O/'safe-root-closure-review.json',{'status':'PASS','audit_sha256':sha(R/'declaration-audit.json'),'baseline_graph_result_sha256':sha(P/'graph-consistency-v1-command/stdout.txt'),'safe_roots':safe_checks,'safe_union_size':len(safe_union),'safe_generated_closed_roots':[x['name'] for x in safe_checks if x['generated_closed_name']],'excluded_exact_helper_names':sorted(unsafe),'excluded_runtime_sentinels':sorted(sentinels),'scope':'Every safe originating declaration, including safe generated closed definitions; no capstone-only restriction. Graph extraction remains the verifier inspector, independently checked for consistency.'})
  save(O/'runtime-helper-classification.json',{'status':'CLASSIFIED_UNREACHABLE_FROM_ALL_SAFE_ROOTS','helpers':helper_rows,'helper_count':22,'unsafe_axiom_kind_count':sum(x['kind']=='axiom' for x in helpers),'safe_root_count':74,'scope':'These runtime declarations remain inventoried. They are not authored proof axioms, and their presence is not treated as acceptance of unsafe proof dependencies.','printing_receipt_sha256':sha(P/'runtime-helper-review-v2/receipt.json')})
  for n,digest in f['files'].items():
   req(sha(P/'frozen-project-v1'/n)==digest,'Frozen source changed: '+n)
   if n.endswith('.lean') or n in {'lean-toolchain','lake-manifest.json'}:req(sha(R/'project'/n)==digest,'Review source copy changed: '+n)
  for name in ['lean-toolchain','lake-manifest.json']:req((P/'expected-pins'/name).read_bytes()==(P/'frozen-project-v1'/name).read_bytes(),'Expected pin mismatch')
  plan=read(P/'engineering-plan/plan.json');req(all(sha(D/'verification-tools'/n)==h for n,h in plan['tool_sha256'].items()),'Tool changed')
  all_source='\n'.join((P/'frozen-project-v1'/n).read_text() for n in f['files'] if n.endswith('.lean'))
  req(not any(n in all_source for n in unsafe),'Runtime helper explicitly appears in frozen source')
  expected_products={m.replace('.','/')+'.olean' for m in s['modules']}
  for name in ['lake-build-outputs.json','replay-build-outputs.json']:
   products=read(R/name);req(set(products)==expected_products,'Default/full replay module coverage incomplete')
  for name,digest in read(R/'replay-build-outputs.json').items():req(sha(R/'project/.lake/build/lib/lean'/name)==digest,'Owned replay object changed')
  for p,digest in read(R/'runtime-identities.json').items():req(sha(Path(p))==digest,'Runtime changed')
  for x in read(R/'stock-index-stability.json'):
   root=D/'runtime/stock1925' if x['package']=='mathlib' else D/'runtime/stock1925/.lake/packages'/x['package']
   req(x['unchanged'] and sha(root/'.git/index')==x['after'],'Reference index changed')
  imports=read(R/'import-identities.json');req(len(imports)==4063 and len({r['module'] for r in imports})==4063,'Import inventory mismatch')
  req({r['module'] for r in imports}==set(data['imported_modules']),'Imported module coverage mismatch')
  req(set(read(R/'control-results.json')[i]['fixture'] for i in range(6))=={'Good','Axiom','Transitive','Sorry','Native','Unsafe'},'Control coverage')
  build=read(R/'receipts/0039.json');req('--no-cache' in build['argv'] and '--wfail' in build['argv'],'Build flags absent')
  replay_receipts=[read(R/'receipts'/f'{i:04d}.json') for i in range(40,47)]
  req(all('-DwarningAsError=true' in r['argv'] for r in replay_receipts),'Strict replay missing')
  source_tree={r['path']:r for r in read(P/'compiler-provenance-v1/tree.json')['tree']};commit=read(P/'compiler-provenance-v1/selected-commit.json')['commit'];req(commit=='6caaee842e9495688c1567e78c0e68dbb96942aa','Compiler commit mismatch')
  provenance=[]
  for directory in ['compiler-source-provenance-v1','compiler-stage-provenance-v1']:
   ps=read(P/directory/'summary.json');req(ps['status']=='PASS' and ps['commit']==commit,'Source provenance incomplete')
   for row in ps['files']:
    p=P/directory/row['path'];body=p.read_bytes();blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest();req(sha(p)==row['sha256'] and blob==row['git_blob']==source_tree[row['path']]['sha'],'Compiler source identity mismatch');provenance.append({'evidence':str(p.relative_to(P)),**{k:row[k] for k in ['url','sha256','git_blob','bytes']}})
  runtime=D/'runtime/lean-4.19.0-darwin_aarch64';licenses=[]
  for name in ['LICENSE','LICENSES']:
   src=runtime/name;body=src.read_bytes();blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest();req(blob==source_tree[name]['sha'],'License source mismatch');dst=O/'licenses'/name;dst.parent.mkdir(exist_ok=True);dst.write_bytes(body);licenses.append({'file':str(dst.relative_to(P)),'upstream_path':name,'git_blob':blob,'sha256':sha(dst)})
  bundled=[]
  for relative,lo,hi in [('Lean/Compiler/Old.lean',12,21),('Init/Prelude.lean',136,171)]:
   src=runtime/'src/lean'/relative;body=src.read_bytes();blob=hashlib.sha1(b'blob '+str(len(body)).encode()+b'\0'+body).hexdigest();req(blob==source_tree['src/'+relative]['sha'],'Bundled compiler source differs from official commit')
   text=''.join(src.read_text().splitlines(keepends=True)[lo-1:hi]);dst=O/'compiler-excerpts'/(Path(relative).name+'.txt');dst.parent.mkdir(exist_ok=True);dst.write_text(text);bundled.append({'source':str(src),'upstream_path':'src/'+relative,'git_blob':blob,'source_sha256':sha(src),'first_line':lo,'last_line':hi,'excerpt':str(dst.relative_to(P)),'excerpt_sha256':sha(dst)})
  save(O/'compiler-provenance.json',{'status':'PASS','official_tag':'v4.19.0','official_commit':commit,'sources':provenance,'bundled_excerpts':bundled,'licenses':licenses,'root_NOTICE_present':'NOTICE' in source_tree,'anchors':[{'file':'src/library/compiler/eager_lambda_lifting.cpp','lines':[237,246],'meaning':'next_name plus unsafe/meta axiom registration and corresponding compiled body'},{'file':'src/library/compiler/util.cpp','lines':[561,573],'meaning':'stage1/stage2 declarations explicitly registered unsafe'},{'file':'src/library/compiler/compiler.cpp','lines':[220,264],'meaning':'eager lifting, stage caching and closed-term extraction pipeline'},{'file':'src/library/compiler/extract_closed.cpp','lines':[18,24],'meaning':'generated closed-term names'}],'limit':'Official source identities corroborate runtime compiler behavior; no compiler bootstrap or independent rebuild is claimed.'})
  save(O/'receipt-review.json',{'status':'PASS','verifier_raw_receipts':61,'reviewed_total_command_receipts':len(receipts),'records':receipts,'retained_failed_probe':'runtime-helper-review-v1/receipt.json','failure_reason':'Unsupported pp.width formatting option; candidate proof verifier completed successfully and corrected print-only probe passed.'})
  save(O/'graph-consistency.json',{'status':'PASS','audit_sha256':sha(R/'declaration-audit.json'),'tool_sha256':sha(D/'verification-tools/check_audit_graph.py'),'command_record':'graph-consistency-v1-command/receipt.json','result':graph_report})
  evidence_roots=['engineering-review-v1','engineering-review-v1-command','graph-consistency-v1-command','runtime-helper-review-v1','runtime-helper-review-v2','compiler-provenance-v1','compiler-provenance-v1-command','compiler-source-provenance-v1','compiler-source-provenance-v1-command','compiler-stage-provenance-v1','compiler-stage-provenance-v1-command','engineering-finalization-v1','engineering-finalization-v1-command']
  extra=['engineering-source-review-v1.json','engineering-plan/plan.json','inspect_runtime_helpers.py','inspect_runtime_helpers_v2.py','retrieve_compiler_tree.py','retrieve_compiler_sources.py','retrieve_compiler_stages.py','finalize_engineering.py','frozen-v1.json']
  save(O/'packaging-evidence.json',{'required_roots_relative_to_candidate':evidence_roots,'required_extra_files_relative_to_candidate':extra,'dependency_provenance_record':'dependency-readiness.json','dependency_provenance_note':'Preserve all 447 files listed by that record if redistributing the dependency restoration history; include its 123 raw receipts and failed initial index-byte check/adjudication.','exclude':['All .lake project/dependency caches and copied dependency trees','Compiled binary artifacts such as .olean/.ilean/.o/.a/.dylib','Active adversarial or inspection Lean modules outside archived fixtures'],'preserve':['All 61 raw verifier command receipts and output files','Complete declaration audit, helper inventory, source/cache/import inventories, control-results and control graph JSON files','Archived original inspector, inspection and control source inputs as inert evidence, not default project roots','Both failed and corrected helper probes, exact compiler sources plus LICENSE and LICENSES, official tag/tree/HTTP records','Final source remains the exact frozen author source; finalization does not rewrite verifier summary']})
  summary.update(status='PASS',frozen_manifest_sha256=sha(frozen),frozen_files=f['files'],modules=s['modules'],capstones=f['capstones'],default_target_covers_all_modules=True,local_declarations=96,safe_originating_declarations=74,classified_unsafe_generated_helpers=22,unsafe_generated_axiom_kind_helpers=2,closure_declarations=20672,safe_closure_union_size=len(safe_union),uniquely_resolved_imports=4063,all_safe_roots_exclude_all_helpers_and_runtime_sentinels=True,all_safe_roots_axioms_permitted=True,permitted_axioms=sorted(permitted),verifier_raw_receipts=61,reviewed_command_receipts=len(receipts),source_config_strict_replays=7,full_lake_build_flags=['--no-cache','--wfail'],lean_control_fixtures=6,source_pins=s['package_identities'],stock_indexes_runtime_and_frozen_sources_unchanged=True,prior_summary_status=s['status'],prior_summary_sha256=sha(R/'summary.json'),reports={n:sha(O/n) for n in ['runtime-helper-classification.json','safe-root-closure-review.json','compiler-provenance.json','receipt-review.json','graph-consistency.json','packaging-evidence.json']},required_evidence_roots=evidence_roots,limitations=s['limits']+['Runtime-only generated unsafe declarations include two lifted-lambda axiom entries; they remain inventoried and are absent from every safe originating-root closure.','Compiler source provenance is checked against the exact official release tree; runtime is not rebuilt.','One display-only helper probe failed due to unsupported pp.width; its corrected rerun passed and both receipts are retained.'])
 except Exception as e:
  summary.update(status='FAIL',error=repr(e));raise
 finally:
  summary['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save(O/'summary.json',summary);print(json.dumps({k:summary.get(k) for k in ['status','local_declarations','safe_originating_declarations','classified_unsafe_generated_helpers','closure_declarations','uniquely_resolved_imports','reviewed_command_receipts','error']},indent=2))
if __name__=='__main__':main()
