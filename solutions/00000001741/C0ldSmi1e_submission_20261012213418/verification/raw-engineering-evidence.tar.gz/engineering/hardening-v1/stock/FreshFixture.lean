def fixture : Nat := 0
