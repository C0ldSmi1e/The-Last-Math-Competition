# Independent preliminary semantic review — 00000007160

Status: preliminary assessment only. No author source, report, project, compiled artifact, or previous submission has been inspected. This document is not a final verification or an authorization to publish.

## Evidence and scope

The reviewer read the entire bilingual `00000007160.md`, `RULES.en.md`, and `RULES.zh-CN.md` from `clean-author-input`. The exact byte hashes are recorded in `READ_HASH_MANIFEST.json`. The reviewer has not inspected earlier competition submissions, sessions, selector/root notes, neighboring problems, or competing proofs. The proposed mathematical target was supplied in the review request; the analysis below is independent of any author proof.

The English statement says that the spectra of normal matrices are Lipschitz with the Frobenius norm as constant and names “Frobenius Hoffman-Wielandt spectral Lipschitz.” The Chinese statement likewise says “正规矩阵” (normal matrices), explicitly names Hoffman–Wielandt, and refers to Frobenius norm and Lipschitz behavior. Neither language supplies a field, matrix size convention, matching metric, multiplicity convention, or a displayed inequality.

## Preliminary judgment on the proposed target

For every finite size n and every pair of complex normal n-by-n matrices A and B, take complete lists λ and μ of their eigenvalues counted with algebraic multiplicity. The proposed conclusion

    ∃ σ ∈ S_n,  Σ_i |λ_i − μ_(σ(i))|² ≤ Σ_(i,j) |A_(i,j) − B_(i,j)|²

is a faithful conventional precise formulation of the named Hoffman–Wielandt claim in both languages. There is no identified substantive mismatch between that target and either language. The complex domain also covers real normal matrices after complexification, provided a report does not instead restrict a real matrix's eigenvalue list to real numbers.

This judgment depends on identifying “spectra” with eigenvalue multisets and the spectral metric with minimum ℓ² matching distance. That is the natural completion of the named theorem, but it is an interpretation that must be disclosed because the original prose leaves the metric unstated. The report should state the definitions before claiming equivalence. The Frobenius norm is the norm controlling changes in the input; the Lipschitz constant in the precise formulation is 1. It would be misleading to describe an individual matrix's Frobenius norm as a fixed Lipschitz constant.

The target is a pairwise matching assertion. It does not assert a globally consistent Lipschitz labeling of eigenvalues across all normal matrices. No such stronger assertion is needed to satisfy this formulation.

## Domain and boundary cases to audit in the final source

1. Normality must mean A A* = A* A and separately B B* = B* B. A proof restricted to Hermitian, real symmetric, diagonal, or commuting normal pairs would not establish the requested general case. The matrices need not commute with one another.
2. Both matrices have the same arbitrary finite size. A fixed concrete size, a finite numerical sample, or an unmentioned dimension-dependent loss would not suffice.
3. Include n = 0 if the formal theorem says all finite n; its sums are zero and its permutation is the unique empty permutation. A theorem expressly for positive n would cover the usual nonempty convention but should either disclose that scope or add the vacuous empty case before claiming all finite n.
4. Include n = 1, zero matrices, equal matrices, repeated eigenvalues, zero eigenvalues, and nonreal eigenvalues. No simple-spectrum, invertibility, ordering, strict positivity, or spectral-separation hypothesis is justified by the original.
5. An eigenvalue list has n entries and retains algebraic multiplicities. Merely enumerating distinct eigenvalues or taking an arbitrary set of eigenvalues is insufficient for this target.
6. The supplied enumeration of each spectrum may be arbitrary. If the principal theorem uses a particular spectral-theorem enumeration, a bridge must show that the matching metric or existential matching conclusion is independent of that choice. Equivalently, the report may define the multiset directly through the diagonalization and prove it is the characteristic-polynomial multiset.
7. Complex absolute value must be complex modulus; the cost and bound are real and nonnegative. The Frobenius norm is the square root of the sum of squared entry moduli. Operator norm, an entrywise sum norm, or a normalized Frobenius norm would require explicit conversion and would change the displayed formulation.

## Formal bridges required for a complete proof

The exact proof architecture is the author's choice. Regardless of architecture, the final Lean declarations and report must establish the following links rather than assume the desired spectral statement under alternate names.

* Every complex finite normal matrix in the theorem's domain admits the spectral data used by the proof. If unitary diagonalization witnesses are inputs to a core lemma, a final theorem must obtain them from normality. A lemma only about arbitrary provided diagonalizations is a useful intermediate result, not the whole conjecture.
* Diagonal entries or “eigenvalues” defined in the formal development really enumerate the matrix's characteristic roots, with algebraic multiplicity. A determinant/characteristic-polynomial identity or a precisely applicable library theorem can provide this bridge. Merely proving that each value has a nonzero eigenvector does not establish multiplicity completeness.
* The formal matrix expression for the bound equals Σ_(i,j) |A_(i,j) − B_(i,j)|². If a matrix norm instance is used, inspect its actual definition and normalization. If the proof changes orthonormal basis, establish the relevant Frobenius invariance or expansion.
* The output matching is a bijective permutation of the complete index type, not an arbitrary function that may reuse eigenvalues. Permutation inverses or transposes introduced by a trace calculation must be tracked correctly.
* If the proof passes through a doubly stochastic matrix, prove both row and column sums and nonnegativity from the actual unitary data. The step from the weighted cost to one permutation with no larger cost must itself be a proved theorem or a correctly instantiated library result, including empty dimension.
* If the proof uses a trace, complex inner product, or real-part expansion, justify conjugation conventions and the conversion to the real squared distance. In particular, an inequality for real parts of products alone is not yet the stated spectral distance estimate.
* A minimum matching distance must be defined over the nonempty finite set of all permutations (nonempty also at n = 0). If the report claims an optimal distance exists, prove attainment or use the finite minimum directly. Passing from the squared inequality to distance ≤ Frobenius norm requires the correct nonnegative square-root argument.
* Calling the spectral map “Lipschitz” requires matching-distance well-definedness on multisets. A complete metric or pseudometric structure can be supplied, or the report can explicitly take the displayed pairwise estimate as its precise formulation. If it introduces an actual `LipschitzWith` assertion, audit that the domain norm and codomain metric are exactly the intended ones.

The constant 1 is sharp in nonempty dimension: for n = 1 the two sides of the squared inequality are equal for arbitrary scalar entries. A sharpness theorem is useful if “optimal” is intended to modify the Lipschitz constant. If “optimal” only describes minimization over matchings, sharpness is not required, but minimum attainment is.

## Rules relevant to the later full review

Both rule versions require a full reading of the entire LaTeX report, a Lean project that compiles and runs completely, no `sorry` or other source of an incomplete proof, semantic agreement with the conjecture, and execution/verification of any auxiliary computational material. Both also require the solver's package to include LaTeX, PDF, and Lean 4 sources under the personal submission directory and disallow solver changes to unrelated repository files.

This preliminary review does not discharge those duties: no build, axiom audit, report-to-source mapping, PDF check, auxiliary-code check, or complete source review has occurred. The later review should use a frozen file manifest, read every proof and report line, compile from the supplied project configuration, inspect theorem assumptions and proof axioms, and explicitly distinguish substantive semantic failures from editorial clarifications. Repository publication and maintainer actions are outside this reviewer's task authorization.
