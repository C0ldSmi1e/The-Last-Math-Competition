import Conjecture1925
set_option pp.all true
set_option pp.width 120
#print Conjecture1925.base._cstage1
#print Conjecture1925.base._cstage2
#print Conjecture1925.cycleLength._cstage1
#print Conjecture1925.cycleLength._cstage2
#print Conjecture1925.instMeasurableSpaceΩ._closed_1._cstage2
#print Conjecture1925.instMeasurableSpaceΩ._cstage1
#print Conjecture1925.instMeasurableSpaceΩ._cstage2
#print Conjecture1925.observable._cstage1
#print Conjecture1925.observable._cstage2
#print Conjecture1925.rotation._closed_1._cstage2
#print Conjecture1925.rotation._closed_2._cstage2
#print Conjecture1925.rotation._closed_3._cstage2
#print Conjecture1925.rotation._cstage1
#print Conjecture1925.rotation._cstage2
#print Conjecture1925.rotation._elambda_1
#print Conjecture1925.rotation._elambda_1._cstage1
#print Conjecture1925.rotation._elambda_1._cstage2
#print Conjecture1925.rotation._elambda_2
#print Conjecture1925.rotation._elambda_2._cstage1
#print Conjecture1925.rotation._elambda_2._cstage2
#print Conjecture1925.squareTime._cstage1
#print Conjecture1925.squareTime._cstage2
