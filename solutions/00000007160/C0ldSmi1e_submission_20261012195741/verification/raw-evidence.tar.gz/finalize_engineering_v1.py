#!/usr/bin/env python3
"""Finalize the actual candidate audit and classify its 13 compiler helpers.

Usage: python3 -B SCRIPT REVIEW FROZEN SOURCE STOCK RUNTIME GRAPH_RECEIPT NEW_OUT
This is read-only postprocessing of a completed Lean build/audit. It supplies
no independent kernel checking and never repairs or overrides audit failures.
"""
import collections
import hashlib
import json
import os
from pathlib import Path
import sys

if not __debug__:raise RuntimeError('Assertions must be enabled')
REVIEW,FROZEN,SOURCE,STOCK,RUNTIME,GRAPH,OUT=map(lambda p:Path(p).resolve(),sys.argv[1:])
OUT.mkdir(parents=True,exist_ok=False)
(OUT/'driver.py.txt').write_bytes(Path(__file__).read_bytes())
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def require(ok,msg):
    if not ok:raise RuntimeError(msg)

summary=read(REVIEW/'summary.json');frozen=read(FROZEN)
audit=read(REVIEW/'declaration-audit.json')
require(summary['status']=='PASS_PENDING_RUNTIME_HELPER_CLASSIFICATION','Unexpected verifier status')
require(summary['frozen_manifest_sha256']==sha(FROZEN),'Frozen selection differs')
for p,h in frozen['files'].items():
    require(sha(SOURCE/p)==h and sha(REVIEW/'project'/p)==h,'Frozen input changed: '+p)
graph_receipt=read(GRAPH/'receipt.json')
require(graph_receipt['exit_code']==0,'Graph checker failed')
for ext in ['stdout','stderr']:
    require(sha(GRAPH/(ext+'.txt'))==graph_receipt[ext+'_sha256'],'Graph output changed')
graph_result=read(GRAPH/'stdout.txt')
require(graph_result['status']=='PASS','No graph PASS')
require(Path(graph_receipt['argv'][-1]).resolve()==(REVIEW/'declaration-audit.json').resolve(),'Graph checker input mismatch')
roots={r['name']:r for r in audit['declarations']}
require(len(roots)==len(audit['declarations'])==49,'Unexpected declaration coverage')
expected_modules={'Frobenius':10,'HoffmanWielandt':7,'Matching':1,'NormalSpectral':5,'Reindexing':3,'Verification':23}
require(dict(collections.Counter(r['module'] for r in roots.values()))==expected_modules,'Originating-module counts changed')
require(set(audit['requested_modules'])==set(expected_modules),'Unexpected requested modules')
require(not audit['failures'] and audit['strict_dependency_policy'] is True and audit['kernel_check_performed'] is False,'Audit policy/failure mismatch')
allowed={'propext','Classical.choice','Quot.sound'}
require(set(audit['permitted_axioms'])==allowed,'Permitted axiom set changed')
unsafe={n:r for n,r in roots.items() if r['unsafe']}
safe={n:r for n,r in roots.items() if not r['unsafe']}
expected_unsafe={f'HoffmanWielandtVerification.{owner}._cstage{i}' for owner in ['A','B'] for i in [1,2]}
expected_unsafe|={f'HoffmanWielandtVerification.{owner}._closed_{i}._cstage2' for owner,limit in [('A',6),('B',3)] for i in range(1,limit+1)}
require(set(unsafe)==expected_unsafe,'Unexpected unsafe root needs new review')
helper_records=[]
for n,r in sorted(unsafe.items()):
    owner=n.split('._',1)[0]
    require(r['kind']=='definition' and r['module']=='Verification' and not r['trust_enforced'],'Unexpected helper metadata')
    require(owner in safe and safe[owner]['kind']=='definition' and safe[owner]['module']=='Verification','Missing safe mathematical source definition')
    require(n not in safe[owner]['closure'],'Safe owner reaches compiler helper')
    helper_records.append({'name':n,'owner':owner,'originating_module':r['module'],'kind':r['kind'],
       'classification':'Compiler stage/closed-value runtime helper for a reviewed explicit verification matrix definition',
       'trust_enforced':False,'mathematical_evidence':False})
for n,r in safe.items():
    require(r['trust_enforced'] and set(r['axioms'])<=allowed and not r['unsafe_dependencies'],'Safe declaration trust failure: '+n)
    require(not(set(r['closure'])&set(unsafe)),'Safe root reaches excluded helper: '+n)
capstones=[]
for n in frozen['capstones']:
    r=roots[n]
    require(n in safe and r['kind']=='theorem','Capstone is not a safe theorem')
    capstones.append({'name':n,'type':r['type'],'axioms':r['axioms'],'unsafe_dependencies':r['unsafe_dependencies'],'closure_size':len(r['closure'])})
save(OUT/'runtime-helper-classification.json',{'status':'PASS','safe_root_count':len(safe),'runtime_helper_count':len(unsafe),
 'all_safe_roots_disjoint_from_helpers':True,'helpers':helper_records,
 'basis':'Every authored source was reviewed, with no authored unsafe declarations or environment injection. All 13 names are exact compiler-stage/closed-value forms owned by safe definitions A/B, and no safe declaration depends on them.',
 'limit':'The helper runtime computations are not mathematical evidence and are not claimed safe.'})
save(OUT/'capstone-audit.json',capstones)
imports=read(REVIEW/'import-identities.json')
require(len(imports)==summary['import_identity_count']==4152,'Import count changed')
receipts=sorted((REVIEW/'receipts').glob('*.json'))
require(len(receipts)==61,'Unexpected raw receipt count')
for p in receipts:
    r=read(p)
    require((r['expected_exit']==0 and r['exit_code']==0) or (r['expected_exit']=='nonzero' and r['exit_code']!=0),'Unexpected recorded exit: '+str(p))
    for ext in ['stdout','stderr']:require(sha(p.with_suffix('.'+ext))==r[ext+'_sha256'],'Receipt changed: '+str(p))
for spec in summary['package_identities']:
    name=spec['package'];root=STOCK if name=='mathlib' else STOCK/'.lake/packages'/name
    original=read(REVIEW/'stock'/(name+'-cache.json'))
    actual={str(p.relative_to(root/'.lake/build/lib/lean')):sha(p) for p in (root/'.lake/build/lib/lean').rglob('*.olean')}
    require(actual==original,'Immutable stock cache changed: '+name)
    for row in read(REVIEW/'stock'/(name+'.json')):
        p=root/row['file'];data=os.fsencode(os.readlink(p)) if p.is_symlink() else p.read_bytes()
        require(hashlib.sha256(data).hexdigest()==row['sha256'],'Immutable tracked stock source changed: '+name+'/'+row['file'])
for r in read(REVIEW/'stock-index-stability.json'):
    root=STOCK if r['package']=='mathlib' else STOCK/'.lake/packages'/r['package']
    require(r['unchanged'] and sha(root/'.git/index')==r['before'],'Immutable stock index changed')
for p,h in read(REVIEW/'runtime-identities.json').items():require(sha(Path(p))==h,'Runtime identity changed')
require((RUNTIME/'bin/lean').resolve()==Path(read(REVIEW/'receipts/0001.json')['argv'][0]).resolve(),'Runtime root mismatch')
result={'status':'PASS','frozen_manifest_sha256':sha(FROZEN),'tested_source_sha256':frozen['files'],
 'declaration_audit_sha256':sha(REVIEW/'declaration-audit.json'),'source_modules':summary['modules'],
 'local_declaration_count':49,'safe_declaration_count':len(safe),'generated_runtime_helper_count':len(unsafe),
 'module_counts':expected_modules,'closure_declaration_count':audit['closure_declaration_count'],
 'import_identity_count':len(imports),'import_packages':dict(collections.Counter(r['package'] for r in imports)),
 'raw_command_receipts':len(receipts),'lake_build':'--no-cache --wfail build passed',
 'source_replay':'All six mathematical source files and lakefile.lean directly replayed with warningAsError=true',
 'capstones':frozen['capstones'],'axiom_allowlist':sorted(allowed),'audit_failures':[],
 'stock_source_cache_indexes_unchanged':True,'runtime_identities_unchanged':True,'graph_consistency':'PASS',
 'helper_classification_sha256':sha(OUT/'runtime-helper-classification.json'),
 'supersedes_pending_classification_status_only':str(REVIEW/'summary.json'),
 'limits':summary['limits']+['Generated runtime helpers are excluded from mathematical evidence; none is reachable from any safe local declaration.',
 'Source compilation supplies kernel checking; the inspector and graph checker are not independent kernel recheckers.',
 'Semantic and report reviews are outside this engineering result.']}
save(OUT/'summary.json',result);print(json.dumps(result,indent=2))
