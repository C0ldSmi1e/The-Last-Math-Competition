#!/usr/bin/env python3
"""Operational preparation only; never reads candidate mathematical sources."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

D = Path('/Users/daniel/.codex/visualizations/2026/10/04/01a10508-f155-7f33-b06c-d34f02168fbf/competition-work')
E = D / '1741/engineering'
STOCK = D / 'runtime/stock1925'
LEAN_BIN = D / 'runtime/lean-4.19.0-darwin_aarch64/bin'
PINS = D / '1741/clean-author-input'
VERIFIER = D / 'verification-tools/verify.py'
TEMPLATE = D / 'verification-tools/templates/ClosureAudit.lean.txt'
OUT = E / 'prepare-001'

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

env = dict(os.environ)
for key in list(env):
    if key.startswith('GIT_'):
        del env[key]
env['GIT_OPTIONAL_LOCKS'] = '0'
env['GIT_NO_REPLACE_OBJECTS'] = '1'

def git(path, *args):
    return subprocess.check_output(['/usr/bin/git', *args], cwd=path, env=env)

assert not OUT.exists(), 'Fresh preparation output must not already exist'
start = time.time()
identity = {
    'purpose': 'Generic Lean verifier preparation only',
    'candidate_mathematical_source_accessed': False,
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'stock_path': str(STOCK),
    'lean_bin_path': str(LEAN_BIN),
    'preparation_output': str(OUT),
    'orchestrator': {'path': str(Path(__file__)), 'sha256': sha(Path(__file__))},
    'verifier': {'path': str(VERIFIER), 'sha256': sha(VERIFIER)},
    'template': {'path': str(TEMPLATE), 'sha256': sha(TEMPLATE)},
    'expected_pins': {name: {'path': str(PINS/name), 'sha256': sha(PINS/name)}
                      for name in ('lean-toolchain', 'lake-manifest.json')},
    'prior_generic_readiness_provenance': {
        'path': str(D/'1925/root-dependency-readiness-review.json'),
        'sha256': sha(D/'1925/root-dependency-readiness-review.json'),
        'role': 'Historical dependency provenance; not evidence of this fresh preparation run'},
    'packages': [],
}
manifest = json.loads((PINS/'lake-manifest.json').read_text())
assert (PINS/'lean-toolchain').read_text().strip() == 'leanprover/lean4:v4.19.0'
for spec in manifest['packages']:
    name = spec['name']
    path = STOCK if name == 'mathlib' else STOCK/'.lake/packages'/name
    actual_head = git(path, 'rev-parse', 'HEAD').decode().strip()
    status = git(path, 'status', '--porcelain', '--untracked-files=no').decode()
    assert actual_head == spec['rev'], (name, 'Revision mismatch')
    assert not status, (name, 'Tracked changes')
    index = path/'.git/index'
    source_rows = []
    for entry in filter(None, git(path, 'ls-tree', '-r', '-z', 'HEAD').split(b'\0')):
        meta, relative = entry.split(b'\t', 1)
        mode, obj_type, expected_blob = meta.decode().split()
        assert obj_type == 'blob', (name, relative, 'Unexpected non-blob')
        relative = relative.decode()
        source = path/relative
        data = os.readlink(source).encode() if source.is_symlink() else source.read_bytes()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert blob == expected_blob, (name, relative, 'Pinned source differs')
        source_rows.append({'path': relative, 'mode': mode, 'git_blob': blob,
                            'sha256': hashlib.sha256(data).hexdigest()})
    cache = path/'.lake/build/lib/lean'
    cache_rows = {str(p.relative_to(cache)): sha(p) for p in sorted(cache.rglob('*.olean'))}
    source_file = E/'stock-identities-002'/(name+'-sources.json')
    cache_file = E/'stock-identities-002'/(name+'-oleans.json')
    save(source_file, source_rows)
    save(cache_file, cache_rows)
    identity['packages'].append({
        'name': name, 'path': str(path), 'url': spec['url'],
        'expected_revision': spec['rev'], 'actual_revision': actual_head,
        'tracked_status': status, 'source_file_count': len(source_rows),
        'source_inventory': str(source_file), 'source_inventory_sha256': sha(source_file),
        'olean_count': len(cache_rows), 'olean_inventory': str(cache_file),
        'olean_inventory_sha256': sha(cache_file),
        'index_sha256_before': sha(index) if index.is_file() else None})
    print(name + ': pinned sources and ' + str(len(cache_rows)) + ' cache modules recorded', flush=True)
save(E/'preparation-identities.json', identity)
argv = [sys.executable, str(VERIFIER), 'prepare', str(STOCK), str(LEAN_BIN), str(OUT)]
command_start = time.time()
result = subprocess.run(argv, cwd=E, env=env, capture_output=True)
(E/'prepare-command.stdout').write_bytes(result.stdout)
(E/'prepare-command.stderr').write_bytes(result.stderr)
save(E/'prepare-command.json', {
    'argv': argv, 'cwd': str(E), 'exit_code': result.returncode,
    'seconds': time.time() - command_start,
    'stdout_sha256': sha(E/'prepare-command.stdout'),
    'stderr_sha256': sha(E/'prepare-command.stderr')})
print(result.stdout.decode(errors='replace'), end='', flush=True)
print(result.stderr.decode(errors='replace'), end='', file=sys.stderr, flush=True)
assert result.returncode == 0, 'Preparation failed; all output retained'
summary = json.loads((OUT/'summary.json').read_text())
assert summary['status'] == 'PREPARATION_PASS'
assert summary['author_proof_accessed'] is False
assert sha(VERIFIER) == identity['verifier']['sha256'] == sha(OUT/'driver.py.txt')
assert sha(TEMPLATE) == identity['template']['sha256'] == summary['inspector_sha256']
runtime = json.loads((OUT/'runtime-identities.json').read_text())
assert all(sha(Path(path)) == digest for path, digest in runtime.items())
for name, row in identity['expected_pins'].items():
    assert sha(PINS/name) == row['sha256'], 'Pin changed'
for row in identity['packages']:
    path = Path(row['path'])
    index = path/'.git/index'
    after = sha(index) if index.is_file() else None
    assert after == row['index_sha256_before'], 'Stock Git index changed'
    row['index_sha256_after'] = after
    row['index_unchanged'] = True
    assert git(path, 'rev-parse', 'HEAD').decode().strip() == row['actual_revision']
    assert not git(path, 'status', '--porcelain', '--untracked-files=no').decode()
save(E/'preparation-identities.json', identity)
save(E/'preparation-review.json', {
    'status': 'PASS_GENERIC_PREPARATION_ONLY',
    'candidate_mathematical_source_accessed': False,
    'candidate_theorem_verified': False,
    'preparation_summary': str(OUT/'summary.json'),
    'preparation_summary_sha256': sha(OUT/'summary.json'),
    'identity_record': str(E/'preparation-identities.json'),
    'identity_record_sha256': sha(E/'preparation-identities.json'),
    'runtime_identity_record': str(OUT/'runtime-identities.json'),
    'runtime_identity_record_sha256': sha(OUT/'runtime-identities.json'),
    'runtime_files_rehashed': len(runtime),
    'controls': summary['controls'],
    'retained_unexpected_failures': [str(E/'retained-failure-001/observed-result.json')],
    'limits': [
        'Only newly generated generic operational fixtures were compiled.',
        'Preparation does not clone packages or execute the candidate build.',
        'Pinned generic source bytes were checked against Git object identities.',
        'Cached dependency oleans were hashed, not independently authenticated or rebuilt.',
        'Supplied Lean runtime executables and dylibs were hashed and stability checked, not bootstrapped.',
        'No candidate theorem, statement, solution, or proof was read or verified.'
    ],
    'seconds': time.time() - start})
print('PASS_GENERIC_PREPARATION_ONLY', flush=True)
