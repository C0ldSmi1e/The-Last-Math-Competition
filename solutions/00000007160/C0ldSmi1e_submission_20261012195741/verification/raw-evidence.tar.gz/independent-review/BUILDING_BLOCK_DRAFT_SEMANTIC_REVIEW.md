# Independent draft building-block semantic review — 00000007160

Stage: the three completed building blocks, before final capstone and project freeze. No whole-conjecture certification is made. The reviewer read every line of each source, preserved exact snapshots, independently compiled them, and audited all their declarations. No author source was edited and the shared generic runtime was used read-only.

| File | Lines | SHA-256 |
| --- | ---: | --- |
| `NormalSpectral.lean` | 91 | `79d5085f54cd810184c7ae56613827b63c967311ec6c5629c1b8c2af3473c0f3` |
| `Frobenius.lean` | 97 | `98fc2aff33e116d5c7389529c5df114d0e9291c9ea6c6d13eacaa528ae0e5dc7` |
| `Matching.lean` | 34 | `63635da80b55553c5f50417b55d19949383d127512fbed76507ebe7955b9e651` |

The full source/snapshot paths and hashes are in `BUILDING_BLOCK_DRAFT_MANIFEST.json`. The review concerns these exact versions even if working sources subsequently change. The previously reviewed mathematical report remains the 167-line draft with hash `32bcf04ac091a3fbdeb5e410012bb421c2fbb441c030432b2ece92d0797ed04b`.

## Finding and independent verification

No semantic, mathematical, or compilation defect was found in these versions. Their statements and proofs implement the normal spectral decomposition, characteristic-polynomial identity, Parseval/Frobenius calculations, and Birkhoff cost-selection stages described in the report. These are general theorems; they do not impose simple spectra, nonzero eigenvalues, invertibility, pairwise commutation of the two target normal operators, or a positive-dimension assumption.

Each snapshot was copied to the private `draft-building-block-compile` directory and compiled in dependency order using the supplied Lean 4.19.0 executable, the read-only `runtime/stock7160` Mathlib and package caches, and `-DwarningAsError=true`. All three compiler processes exited 0 with empty stdout and stderr. Outputs were confined to the review directory.

An additional private `BuildingBlockAudit.lean` imported these newly compiled modules and ran `#print axioms` on all 13 declarations, including both Frobenius definitions. It exited 0. Every result lists exactly `propext`, `Classical.choice`, and `Quot.sound`. There is no `sorryAx`, supplied proof axiom, or additional axiom. The inspected sources contain no admitted proof, axiom declaration, unsafe theorem escape, or relevant custom syntax/macro hiding a weaker proposition. Raw compile/audit output and hashes are retained in the manifest and compile directory. This is an independent draft-module check against supplied caches, not the final private full-project rebuild or a rebuild of all Mathlib dependencies.

## `NormalSpectral.lean`: every declaration and proof

The imports provide the standard joint-eigenspace, adjoint, complex-star-module, characteristic-polynomial, and tactic APIs. `noncomputable section` permits classical basis choices and is not a proof admission. The ambient hypotheses are exactly a finite-dimensional complex inner-product space.

1. `normal_exists_eigenbasis`: The normality hypothesis is `Commute (star T) T`. Mathlib's `LinearMap` star instance is explicitly the adjoint, so this is T* T = T T*, equivalent to the report's normality convention. The only size hypothesis is `finrank ℂ E = n`. The theorem produces an entire `OrthonormalBasis (Fin n) ℂ E` and its eigenvalue function, not merely individual eigenvectors or a spanning claim assumed as input.

   The proof takes the real and imaginary self-adjoint parts of T. Their `.property` establishes self-adjointness, and `isSymmetric_iff_isSelfAdjoint` translates this into the hypotheses of the joint-eigenspace theorem. The commutation derivation expands the parts into scalar multiples of T ± T*, then uses T* T = T T*; no stronger commutation assumption is added.

   The joint subspaces are indexed as `eigenspace H p.2 ⊓ eigenspace K p.1`. Mathlib's `directSum_isInternal_of_commute` and `orthogonalFamily_eigenspace_inf_eigenspace` use precisely this coordinate order. Finite-dimensional independence makes the set of nonzero summands finite; restricting to those summands preserves their internal direct sum and orthogonality. `subordinateOrthonormalBasis` constructs the full basis, and its subordinate index places each vector in a joint eigenspace. Applying the two eigenspace equations and H + iK = T gives eigenvalue p.2 + i p.1, with the same orientation as the construction. Although these joint eigenvalue labels are allowed to lie in ℂ, nothing requires a separate reality theorem: the produced complex eigenvalue equation is exactly the target fact.

   There is no `Nonempty`, `Nontrivial`, or n > 0 premise. The finite support may be empty, the orthonormal basis may be indexed by `Fin 0`, and no default element of that support is selected. All claims about individual indices become vacuous at n = 0. This is a genuine full normal spectral theorem including zero dimension.

2. `eigenbasis_toMatrix`: For any finite index type, the matrix of T in the supplied complete orthonormal eigenbasis is the diagonal matrix of λ. The proof expands the coordinate formula and separates i = j from i ≠ j. It relies on the complete basis and its representation, rather than making an unjustified left-eigenvector inference. It omits the otherwise ambient finite-dimensional instance because existence of a finite basis already provides all structure the identity uses.

3. `eigenbasis_charpoly`: The theorem identifies the linear operator's characteristic polynomial with ∏ᵢ(X − C(λᵢ)). It changes to the basis matrix, invokes the proved diagonal identity, expands the characteristic matrix, and takes the determinant of a diagonal matrix. This records all algebraic multiplicities and handles an empty product correctly. It establishes the required operator-level multiplicity bridge. The capstone must still connect the original concrete matrix's characteristic polynomial to this operator's polynomial and, if it quantifies over arbitrary supplied root lists, prove the permutation relationship between equal multisets.

4. `inner_eigenbasis_apply`: The claimed coordinate equation is `<b_i, T x> = λ_i <b_i, x>` with Mathlib's inner product conjugate-linear in the first entry. The proof reconstructs x from its complete basis expansion, applies T, uses each right-eigenvector equation, and evaluates orthonormal inner products. Thus the scalar is λ_i, with no missing conjugation. This is a correctly proved coordinate-functional identity, not an assumption that arbitrary right eigenvectors also provide left eigenvectors.

## `Frobenius.lean`: every declaration and proof

The file imports the proved normal-spectral module and standard matrix/doubly-stochastic definitions. Its main squared-bound definitions do not depend on whichever norm instance a caller chooses for matrices.

1. `frobeniusSq`: This is explicitly the real sum ∑ᵢ∑ⱼ ‖Aᵢⱼ‖² for complex entries. It has no scaling by matrix size, and it uses the complex modulus through the scalar norm.

2. `frobeniusNorm`: This is the real square root of the preceding entrywise sum. The sum is nonnegative because each summand is a square; a final square-root monotonicity proof must use the appropriate positivity facts, but no such fact is incorrectly assumed in this definition.

3. `sum_image_sq_eq_adjoint`: For two complete orthonormal bases b and c of the same finite-dimensional space, Parseval in c expands the squared norms of T(b_i). After interchanging finite sums, `adjoint_inner_left` and symmetry of the inner-product norm turn the summands into those for T*(c_j) in b. Parseval then closes the equality. The exact library adjoint identity has the right argument/conjugation convention. The statement applies to any linear map T, as needed for S − T, without requiring the difference itself to be normal.

4. `sum_image_sq_basis_independent`: Two applications of the preceding equality, both ending with the same sum for T* on c, yield equality of the squared image sums on b and c. No unitary invariance is assumed without proof.

5. `frobeniusSq_toMatrix`: The standard `toMatrixOrthonormal` entry is `<b_i, T(b_j)>`. Interchanging the two finite sums and applying Parseval identifies the explicit Frobenius square with ∑ⱼ ‖T(b_j)‖². Row and column orientations agree with the report.

6. `overlaps_doublyStochastic`: The weight matrix is Wᵢⱼ = ‖<b_i,c_j>‖². The proof uses exactly the standard three-part condition: nonnegative entries, row sums 1, and column sums 1. Norm symmetry and Parseval provide row sums; Parseval directly provides column sums. The unit norms of the basis vectors give 1. For an empty index type the row and column conditions are vacuous, which is mathematically correct and compatible with Birkhoff's empty case.

7. `weighted_cost_eq_frobenius`: This theorem takes complete eigenbases for S and T, derives `<b_i,(S−T)c_j> = (λ_i−μ_j)<b_i,c_j>`, and squares norms to obtain the weighted cost. Parseval gives the image-norm sum on c; the independently proved basis invariance moves that sum to any desired orthonormal coordinate basis e; `frobeniusSq_toMatrix` identifies the final explicit matrix bound. The order Wᵢⱼ times cost(λ_i, μ_j) is consistent throughout. The hypotheses on this intermediate theorem are appropriate because `normal_exists_eigenbasis` supplies them for the final normal-matrix result.

8. `frobeniusNorm_eq_mathlib`: A local instance activates Mathlib's Frobenius norm only within its own section. The proof rewrites that instance's explicit definition and the real square-root/power identities to obtain agreement with the custom definition. The norm instance is baked into this theorem's elaborated right side; it does not assert equality with every alternative matrix norm and does not install a global competing instance. This bridge is accurate and does not change the norm meaning of earlier statements.

## `Matching.lean`: declaration and proof

`exists_perm_cost_le` works for an arbitrary finite square index type, a real doubly stochastic W, and an arbitrary real cost matrix C. No positivity of C is needed: a finite minimum is no greater than any convex average even for negative costs.

The Birkhoff library theorem returns weights w(σ) ≥ 0 with sum 1 and W = ∑σ w(σ) Pσ. Its source explicitly splits empty from nonempty index types; in the empty case it uses weight 1 on the unique permutation. Hence no positive-dimension hypothesis is hidden in its use here.

`exists_min_image` is applied to the universal finite set of permutations, which is nonempty even when the matrix index type is empty because it contains the identity permutation. The proof expands W in the weighted cost, correctly interchanges the three finite sums, and reduces the permutation matrix term to Cᵢ,σ(i). Thus the permutation orientation matches the report and the eventual spectral matching target; an inverse-permutation mismatch is absent. Replacing each selected minimal cost by the candidate cost under its nonnegative weight gives the desired inequality. All needed inequalities are proved, not assumed as an optimization oracle.

## Primary-library checks and scope boundaries

Selected declaration sources were inspected in the generic runtime to confirm their meanings: `JointEigenspace.lean`, `Adjoint.lean`, `Complex/Module.lean`, `Convex/Birkhoff.lean`, `InnerProductSpace/PiL2.lean`, `InnerProductSpace/Spectrum.lean`, `Analysis/Matrix.lean`, `Data/Matrix/DoublyStochastic.lean`, and `LinearAlgebra/Matrix/Permutation.lean`. Hashes and the fact that only selected declarations/surroundings were scanned are recorded in the manifest. These were generic library inspections, not competing solution reads.

The reviewed modules correctly establish the mathematical stages assigned to them. They do not yet contain the final statement about arbitrary original matrices and arbitrary complete eigenvalue lists. The final review must verify the concrete-matrix/operator conversion, transfer of normality and characteristic polynomials, any reindexing of basis size, equality of lists up to permutation, assembly of the matching bound, and the precise minimum-distance/square-root conclusion. Any later edits to these modules require a delta review against these hashes. The final report's validation claims must be updated only after the frozen package has passed its complete engineering and semantic reviews.
