#!/usr/bin/env python3
"""Retrieve only official pinned Lean compiler provenance; no theorem lookup."""
import datetime,hashlib,json,time,urllib.request
from pathlib import Path
P=Path(__file__).resolve().parent;out=P/'compiler-provenance-v1'
assert not out.exists();out.mkdir();(out/'driver.py.txt').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def get(url,name):
 t=time.monotonic();start=datetime.datetime.now(datetime.timezone.utc).isoformat()
 req=urllib.request.Request(url,headers={'User-Agent':'pinned-lean-compiler-provenance','Accept':'application/vnd.github+json'})
 with urllib.request.urlopen(req,timeout=60) as r:body=r.read();status=r.status;headers=dict(r.headers);resolved=r.url
 p=out/name;p.write_bytes(body)
 record={'url':url,'resolved_url':resolved,'status':status,'response_headers':headers,'started_utc':start,'elapsed_seconds':time.monotonic()-t,'body_path':name,'body_sha256':sha(p),'bytes':len(body)}
 (out/(name+'.receipt.json')).write_text(json.dumps(record,indent=2,sort_keys=True)+'\n');return json.loads(body)
base='https://api.github.com/repos/leanprover/lean4'
tag=get(base+'/git/ref/tags/v4.19.0','tag.json');obj=tag['object']
if obj['type']=='tag':obj=get(obj['url'],'tag-object.json')['object']
assert obj['type']=='commit' and obj['sha'].startswith('6caaee842e94')
tree=get(base+'/git/trees/'+obj['sha']+'?recursive=1','tree.json');assert tree['truncated'] is False
paths=[r for r in tree['tree'] if r['type']=='blob' and 'compiler' in r['path'] and r['path'].endswith(('.cpp','.h'))]
result={'tag':'v4.19.0','commit':obj['sha'],'compiler_source_paths':paths,'scope':'Official compiler implementation provenance only'}
(out/'selected-commit.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
