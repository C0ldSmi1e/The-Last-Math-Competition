# Engineering preparation and checker audit

The original generic Python driver and Lean closure template were fully inspected before any candidate proof was opened. The archived 105 tools were preserved. A fresh APFS clone of stock was created at `/private/tmp/tlmc3348-review-stock/mathlib`; no author compiled artifact was imported.

## Pins

The supplied `lean-toolchain` and `lake-manifest.json` were verified against the clean-input `SHA256SUMS.json`. Lean is `leanprover/lean4:v4.19.0`; Mathlib is commit `c44e0c8ee63ca166450922a373c7409c5d26b00b`. All nine dependency revisions are taken from the exact supplied manifest. The final driver requires byte-identical lock/toolchain files through its final `EXPECTED_PINS` argument.

## Changes and operational controls

The exact archived-to-current changes are retained in `verify.py.diff` and `ClosureAudit.lean.txt.diff`. The modified files and adversarial runner are hashed in `hardened-tool-identities.json`.

The driver now rejects Python optimized mode, clears inherited Git redirection variables, records executable/shared-library hashes, validates stock tracked bytes against pinned Git blob IDs, records pre-build package cache inventories, compares exact pins, checks frozen copied inputs after build/replay, reconciles all own-library `.olean` outputs, and resolves each audited import in the actual direct-replay search path. Unexpected owned modules, duplicate/shadowed import candidates, absent tracked source, and new/changed package cache imports are rejected. The source policy scan processes complete cleaned source so multiline directives do not evade it.

A concrete traversal omission was established: Lean 4.19 `Expr.foldConsts` does not include the structure name carried by `Expr.proj`. The template now recursively traverses every expression constructor and includes projection names, constructor parents, and recursor mutual inductive families. Existing type, body (including opaque body), recursor-rule, and inductive-family traversal remains. The good control asserts these additional graph edges. Audit JSON now says `strict_dependency_policy` and `kernel_check_performed: false`.

`hardened-controls/summary.json` records a good module passing and custom axiom, opaque-transitive axiom, admitted proof, native-decision proof, and unsafe declaration being rejected by the actual inspector. Admitted proof also fails strict source compilation. `hardening-adversarial/results.json` records six rejected tampering/identity cases and multiline/comment/string token controls against actual driver functions. These synthetic fixtures contain no conjecture mathematics.

## Full source and auxiliary review after freeze

After root supplied the frozen manifest, both Lean source files and the TOML configuration were read completely. `frozen-source-review.json` records the review and frozen identity. The candidate uses ordinary definitions, theorem proofs with stock tactics, boundary examples, and `#print axioms` requests. No custom elaborator, macro, initializer, external code, kernel bypass, source mutation, or file/network effect was found. There is no numerical auxiliary computation supporting the mathematical result. The verifier Python, Lean template, test runner, and generated audit/fixture sources are operational tooling, not mathematical premises.

## Invocation

```
python3 /private/tmp/tlmc3348-engineering-tools/verify.py verify SUBMISSION FROZEN_JSON STOCK LEAN_BIN OUT EXPECTED_PINS
```

`prepare STOCK LEAN_BIN OUT` remains available. Output directories must be fresh and are retained on failure.

## Trust boundary

The inspector exports and checks declaration dependency policy. It does not independently kernel-recheck imported declarations; the fresh compilation of owned Lean sources supplies kernel checking. Cached package imports are trusted compiled inputs anchored by byte identity and pinned source inventories; identity does not establish that cached bytes were built from those sources. The supplied Lean runtime is hashed, not bootstrapped. The PATH wrappers only reject common network/Git commands through PATH; they are not an OS network sandbox. Full Mathlib rebuilding, external runtime validation, semantic fidelity, and PDF verification are separate claims.

## Final outcome

Final PASS: `/private/tmp/tlmc3348-independent-engineering-final/REPORT.md`. The initial run was preserved after its import gate caught nine missing stock cache entries. Those exact stock sources were independently compiled with strict flags before the final fresh run. The supplemental graph checker and its corrected adversarial controls are also recorded in this preparation tree.
