#!/usr/bin/env python3
"""Fresh generic Python controls only; no candidate or Lean runtime reads."""
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

REVIEW = Path(__file__).resolve().parent
BASE = REVIEW.parent.parent
SOURCE = BASE / "verification-tools"
TARGET = BASE / "7160/python-hardening"
EXPECTED = {
    "verify.py": "7819063a85d89ad45d9fb31e282c941c3d89b27beb00d7ec459870423c078b89",
    "check_audit_graph.py": "c4b518f02a17db3778a09ddc3987016973ad67ff057c9d03e1b76ed3eeabae61",
    "test_hardening.py": "598da8afd239ec02a5b2a1a9a6914bf7bd06117653289dab148ab5094c6ada3f",
    "templates/ClosureAudit.lean.txt": "65cb76b47ad6bcfa369c446bc16887a8c6ec8409db96c21d17c9f7aca31babbd",
}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n")

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

require(not TARGET.exists(), "Fresh hardening output already exists")
rows = []
for name, expected in EXPECTED.items():
    source = SOURCE / name
    data = source.read_bytes()
    snapshot = REVIEW / "source-snapshots" / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(data)
    actual = hashlib.sha256(data).hexdigest()
    rows.append({"relative_path": name, "source": str(source), "snapshot": str(snapshot),
                 "sha256": actual, "bytes": len(data), "expected_reviewed_sha256": expected,
                 "matches_earlier_review": actual == expected,
                 "mtime_ns": source.stat().st_mtime_ns})
    if source.suffix == ".py":
        ast.parse(data.decode(), filename=str(source))
save(REVIEW / "tool-identities.json", {
    "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "expected_identity_provenance": "Four exact source digests previously reviewed in 3992/recovery-tool-review/identities.json; those digests are comparison inputs only, not fresh test evidence.",
    "files": rows})
require(all(row["matches_earlier_review"] for row in rows), "Copied tool differs from earlier reviewed source")
argv = [sys.executable, "-I", "-B", str(SOURCE / "test_hardening.py"), str(TARGET)]
env = os.environ.copy()
env.pop("PYTHONOPTIMIZE", None)
env["PYTHONDONTWRITEBYTECODE"] = "1"
start = time.monotonic()
receipt = {"started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "argv": argv, "cwd": str(BASE), "python_version": sys.version,
           "platform": platform.platform(), "runner_sha256": digest(Path(__file__)),
           "environment_overrides": {"PYTHONOPTIMIZE": "removed", "PYTHONDONTWRITEBYTECODE": "1"},
           "scope": "Fresh generic synthetic Python fixtures only; no candidate statement/proof/source, Lean executable, or real stock accessed; no Lean process or network invocation.",
           "tool_identities_sha256": digest(REVIEW / "tool-identities.json")}
try:
    result = subprocess.run(argv, cwd=BASE, env=env, capture_output=True)
    (REVIEW / "hardening.stdout").write_bytes(result.stdout)
    (REVIEW / "hardening.stderr").write_bytes(result.stderr)
    receipt.update(exit_code=result.returncode,
                   stdout_sha256=digest(REVIEW / "hardening.stdout"),
                   stderr_sha256=digest(REVIEW / "hardening.stderr"))
    receipt["source_identity_stability"] = {
        row["relative_path"]: digest(Path(row["source"])) == row["sha256"] for row in rows}
    require(result.returncode == 0, "Hardening process failed")
    require(all(receipt["source_identity_stability"].values()), "Tool source changed during run")
    results = json.loads((TARGET / "results.json").read_text())
    receipt["results_sha256"] = digest(TARGET / "results.json")
    receipt["fixture_count"] = len(results)
    require(len(results) == 7, "Unexpected number of synthetic fixture groups")
    require(all(item.get("rejected") is True or item.get("passed") is True for item in results),
            "A synthetic control did not pass")
    receipt["status"] = "PASS"
    print(result.stdout.decode(), end="")
except Exception as error:
    receipt["status"] = "FAIL"
    receipt["error"] = f"{type(error).__name__}: {error}"
    raise
finally:
    receipt["finished_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt["seconds"] = time.monotonic() - start
    receipt["live_handles"] = []
    save(REVIEW / "hardening-receipt.json", receipt)
    print(json.dumps(receipt, indent=2))
