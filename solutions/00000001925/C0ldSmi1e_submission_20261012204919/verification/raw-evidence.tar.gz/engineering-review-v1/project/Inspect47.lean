import Conjecture1925
import Conjecture1925.Counterexample
import Conjecture1925.Dynamics
import Conjecture1925.Measure
import Conjecture1925.Nonconvergence
import Conjecture1925.Tests
import Verification.ClosureAudit
#audit_kernel_modules [Conjecture1925, Conjecture1925.Counterexample, Conjecture1925.Dynamics, Conjecture1925.Measure, Conjecture1925.Nonconvergence, Conjecture1925.Tests] "declaration-audit.json"
